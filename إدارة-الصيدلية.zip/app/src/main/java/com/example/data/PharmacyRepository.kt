package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.firstOrNull
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class PharmacyRepository(private val db: PharmacyDatabase) {

    private val companyDao = db.companyDao()
    private val productDao = db.productDao()
    private val invoiceDao = db.invoiceDao()
    private val userDao = db.userDao()

    // Companies
    val allCompanies: Flow<List<Company>> = companyDao.getAllCompanies()
    fun searchCompanies(query: String): Flow<List<Company>> = companyDao.searchCompanies(query)
    suspend fun getCompanyById(id: Int): Company? = companyDao.getCompanyById(id)
    suspend fun insertCompany(company: Company): Long = companyDao.insertCompany(company)
    suspend fun updateCompany(company: Company) = companyDao.updateCompany(company)
    suspend fun deleteCompany(company: Company) = companyDao.deleteCompany(company)

    // Products
    val allProducts: Flow<List<Product>> = productDao.getAllProducts()
    val allProductsSortedByExpiry: Flow<List<Product>> = productDao.getAllProductsSortedByExpiry()
    val lowStockProducts: Flow<List<Product>> = productDao.getLowStockProducts()
    fun searchProducts(query: String): Flow<List<Product>> = productDao.searchProducts(query)
    suspend fun getProductById(id: Int): Product? = productDao.getProductById(id)
    suspend fun getProductByBarcode(barcode: String): Product? = productDao.getProductByBarcode(barcode)
    suspend fun insertProduct(product: Product): Long = productDao.insertProduct(product)
    suspend fun updateProduct(product: Product) = productDao.updateProduct(product)
    suspend fun deleteProduct(product: Product) = productDao.deleteProduct(product)
    suspend fun updateQuantity(productId: Int, newQuantity: Int) = productDao.updateQuantity(productId, newQuantity)

    // Invoices
    val allInvoices: Flow<List<Invoice>> = invoiceDao.getAllInvoices()
    suspend fun getInvoiceById(id: Int): Invoice? = invoiceDao.getInvoiceById(id)
    fun getItemsForInvoice(invoiceId: Int): Flow<List<InvoiceItem>> = invoiceDao.getItemsForInvoice(invoiceId)

    suspend fun createInvoice(invoice: Invoice, items: List<InvoiceItem>): Long {
        val invoiceId = invoiceDao.insertInvoice(invoice)
        for (item in items) {
            val itemWithInvoiceId = item.copy(invoiceId = invoiceId.toInt())
            invoiceDao.insertInvoiceItem(itemWithInvoiceId)
            
            // Update product stock quantity
            val product = productDao.getProductById(item.productId)
            if (product != null) {
                val newQty = (product.quantity - item.quantity).coerceAtLeast(0)
                productDao.updateQuantity(product.id, newQty)
            }
        }
        return invoiceId
    }

    // Users
    val allUsers: Flow<List<User>> = userDao.getAllUsers()
    suspend fun getUserByUsername(username: String): User? = userDao.getUserByUsername(username)
    suspend fun insertUser(user: User): Long = userDao.insertUser(user)
    suspend fun updateUser(user: User) = userDao.updateUser(user)
    suspend fun deleteUser(user: User) = userDao.deleteUser(user)
    suspend fun updatePassword(userId: Int, passwordHash: String) = userDao.updatePassword(userId, passwordHash)

    // Prepopulate Sample Data if database is empty
    suspend fun prepopulateIfNeeded() {
        val currentUsers = allUsers.first()
        if (currentUsers.isEmpty()) {
            // 1. Create Default Users
            userDao.insertUser(User(username = "admin", passwordHash = "123456", role = "ADMIN", fullName = "د. أحمد المدير"))
            userDao.insertUser(User(username = "staff", passwordHash = "123456", role = "EMPLOYEE", fullName = "الصيدلي عمر"))

            // 2. Create Default Companies
            val c1Id = companyDao.insertCompany(Company(name = "شركة ألفا للأدوية", phone = "0112345678", email = "info@alpha-pharma.com", address = "القاهرة، مصر", notes = "مورد رئيسي للمضادات الحيوية والمسكنات"))
            val c2Id = companyDao.insertCompany(Company(name = "الشركة المتحدة للخدمات الطبية", phone = "0223456789", email = "contact@united-medical.com", address = "الرياض، السعودية", notes = "مستلزمات طبية وأجهزة قياس الضغط والسكري"))
            val c3Id = companyDao.insertCompany(Company(name = "شركة الخليج للصناعات الدوائية (جلفار)", phone = "072461400", email = "info@julphar.net", address = "رأس الخيمة، الإمارات", notes = "أدوية شراب ومراهم جلدية"))
            val c4Id = companyDao.insertCompany(Company(name = "شركة الحكمة للأدوية", phone = "065802400", email = "hikma@hikma.com", address = "عمان، الأردن", notes = "أدوية السكري والضغط والقلب"))

            // Helper to get formatted dates
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val calendar = Calendar.getInstance()

            // Product 1: Normal Product
            calendar.timeInMillis = System.currentTimeMillis()
            calendar.add(Calendar.YEAR, 1)
            val expiry1 = sdf.format(calendar.time)
            calendar.add(Calendar.YEAR, -2)
            val prod1 = sdf.format(calendar.time)
            
            productDao.insertProduct(Product(
                tradeName = "بندول اكسترا (Panadol Extra)",
                scientificName = "Paracetamol + Caffeine",
                manufacturerId = c1Id.toInt(),
                manufacturerName = "شركة ألفا للأدوية",
                category = "مسكنات آلام",
                barcode = "6281102430018",
                purchasePrice = 2000.0,
                salePrice = 3000.0,
                quantity = 150,
                productionDate = prod1,
                expirationDate = expiry1,
                batchNumber = "B90812",
                notes = "يحفظ في مكان بارد وجاف أقل من 30 درجة مئوية",
                lowStockLimit = 15
            ))

            // Product 2: Low Stock
            calendar.timeInMillis = System.currentTimeMillis()
            calendar.add(Calendar.MONTH, 8)
            val expiry2 = sdf.format(calendar.time)
            calendar.add(Calendar.YEAR, -1)
            val prod2 = sdf.format(calendar.time)
            
            productDao.insertProduct(Product(
                tradeName = "أوجمنتين 1 غرام (Augmentin 1g)",
                scientificName = "Amoxicillin + Clavulanic Acid",
                manufacturerId = c1Id.toInt(),
                manufacturerName = "شركة ألفا للأدوية",
                category = "مضادات حيوية",
                barcode = "5011048031542",
                purchasePrice = 12000.0,
                salePrice = 15000.0,
                quantity = 5, // < lowStockLimit 10
                productionDate = prod2,
                expirationDate = expiry2,
                batchNumber = "B22390",
                notes = "مضاد حيوي واسع المجال، يؤخذ تحت إشراف طبي",
                lowStockLimit = 10
            ))

            // Product 3: Nearing Expiration (Expiring in 20 days)
            calendar.timeInMillis = System.currentTimeMillis()
            calendar.add(Calendar.DAY_OF_YEAR, 20)
            val expiry3 = sdf.format(calendar.time)
            calendar.add(Calendar.YEAR, -2)
            val prod3 = sdf.format(calendar.time)

            productDao.insertProduct(Product(
                tradeName = "كونكور 5 ملغ (Concor 5mg)",
                scientificName = "Bisoprolol Fumarate",
                manufacturerId = c4Id.toInt(),
                manufacturerName = "شركة الحكمة للأدوية",
                category = "أدوية الضغط",
                barcode = "4022536706914",
                purchasePrice = 4500.0,
                salePrice = 6000.0,
                quantity = 40,
                productionDate = prod3,
                expirationDate = expiry3,
                batchNumber = "B44201",
                notes = "لتنظيم ضغط الدم، حبة صباحاً",
                lowStockLimit = 10
            ))

            // Product 4: Normal Product
            calendar.timeInMillis = System.currentTimeMillis()
            calendar.add(Calendar.YEAR, 2)
            val expiry4 = sdf.format(calendar.time)
            calendar.add(Calendar.YEAR, -1)
            val prod4 = sdf.format(calendar.time)

            productDao.insertProduct(Product(
                tradeName = "بروفين 400 ملغ (Brufen 400mg)",
                scientificName = "Ibuprofen",
                manufacturerId = c3Id.toInt(),
                manufacturerName = "شركة الخليج للصناعات الدوائية (جلفار)",
                category = "مسكنات ومضادات التهاب",
                barcode = "8002620021021",
                purchasePrice = 1500.0,
                salePrice = 2500.0,
                quantity = 60,
                productionDate = prod4,
                expirationDate = expiry4,
                batchNumber = "B12093",
                notes = "مضاد للالتهاب ومسكن للآلام خافض للحرارة",
                lowStockLimit = 15
            ))

            // Product 5: Low stock + expiring in 5 days!
            calendar.timeInMillis = System.currentTimeMillis()
            calendar.add(Calendar.DAY_OF_YEAR, 5)
            val expiry5 = sdf.format(calendar.time)
            calendar.add(Calendar.YEAR, -2)
            val prod5 = sdf.format(calendar.time)

            productDao.insertProduct(Product(
                tradeName = "فلورست (Flurest)",
                scientificName = "Paracetamol + Pseudoephedrine",
                manufacturerId = c1Id.toInt(),
                manufacturerName = "شركة ألفا للأدوية",
                category = "أدوية الرشح والبرد",
                barcode = "6223002600109",
                purchasePrice = 1000.0,
                salePrice = 1500.0,
                quantity = 2,
                productionDate = prod5,
                expirationDate = expiry5,
                batchNumber = "B11874",
                notes = "علاج أعراض البرد والإنفلونزا",
                lowStockLimit = 10
            ))

            // Product 6: Expired (Expired 30 days ago!)
            calendar.timeInMillis = System.currentTimeMillis()
            calendar.add(Calendar.DAY_OF_YEAR, -30)
            val expiry6 = sdf.format(calendar.time)
            calendar.add(Calendar.YEAR, -2)
            val prod6 = sdf.format(calendar.time)

            productDao.insertProduct(Product(
                tradeName = "جاينو كانديزول (Gyno-Candizol)",
                scientificName = "Butoconazole Nitrate",
                manufacturerId = c3Id.toInt(),
                manufacturerName = "شركة الخليج للصناعات الدوائية (جلفار)",
                category = "مضادات فطريات",
                barcode = "6281003440109",
                purchasePrice = 5000.0,
                salePrice = 7500.0,
                quantity = 0,
                productionDate = prod6,
                expirationDate = expiry6,
                batchNumber = "B77312",
                notes = "كريم مهبلي مضاد للفطريات",
                lowStockLimit = 5
            ))
        }
    }
}
