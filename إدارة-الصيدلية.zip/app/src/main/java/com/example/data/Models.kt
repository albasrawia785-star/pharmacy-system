package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "companies")
data class Company(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val phone: String,
    val email: String,
    val address: String,
    val notes: String
)

@Entity(tableName = "products")
data class Product(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val tradeName: String, // الاسم التجاري
    val scientificName: String, // الاسم العلمي
    val manufacturerId: Int, // معرف الشركة المصنعة
    val manufacturerName: String, // اسم الشركة المصنعة للتسهيل
    val category: String, // التصنيف (مثال: مسكن، مضاد حيوي)
    val barcode: String, // الباركود
    val purchasePrice: Double, // سعر الشراء
    val salePrice: Double, // سعر البيع
    val quantity: Int, // الكمية الحالية
    val productionDate: String, // تاريخ الإنتاج
    val expirationDate: String, // تاريخ الانتهاء
    val batchNumber: String, // رقم التشغيلة
    val imageUri: String? = null, // مسار صورة المنتج
    val notes: String = "", // ملاحظات
    val lowStockLimit: Int = 10 // حد التنبيه للكمية المنخفضة
)

@Entity(tableName = "invoices")
data class Invoice(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val invoiceNumber: String, // رقم الفاتورة التلقائي (مثال: INV-2026-0001)
    val timestamp: Long = System.currentTimeMillis(), // تاريخ ووقت البيع
    val subtotal: Double,
    val discount: Double,
    val tax: Double,
    val total: Double,
    val cashPaid: Double, // المبلغ المدفوع
    val changeDue: Double, // المبلغ المتبقي (الباقي)
    val soldBy: String // اسم الموظف أو المدير الذي باع
)

@Entity(tableName = "invoice_items")
data class InvoiceItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val invoiceId: Int,
    val productId: Int,
    val productName: String,
    val quantity: Int,
    val salePrice: Double,
    val total: Double
)

@Entity(tableName = "users")
data class User(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val username: String,
    val passwordHash: String,
    val role: String, // "ADMIN" or "EMPLOYEE"
    val fullName: String
)
