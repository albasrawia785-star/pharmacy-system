package com.example

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.*
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.CartItem
import com.example.viewmodel.PharmacyViewModel
import java.text.SimpleDateFormat
import java.util.*
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                // Ensure Arabic Right-to-Left (RTL) Layout globally
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    val viewModel: PharmacyViewModel = viewModel()
                    PharmacyAppContent(viewModel)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PharmacyAppContent(viewModel: PharmacyViewModel) {
    val context = LocalContext.current

    // Observe state from ViewModel
    val products by viewModel.allProductsState.collectAsState()
    val companies by viewModel.allCompaniesState.collectAsState()
    val invoices by viewModel.allInvoicesState.collectAsState()
    val lowStockList by viewModel.lowStockState.collectAsState()

    // Dialog control states
    var showAddProductDialog by remember { mutableStateOf(false) }
    var productToEdit by remember { mutableStateOf<Product?>(null) }
    var showAddCompanyDialog by remember { mutableStateOf(false) }
    var companyToEdit by remember { mutableStateOf<Company?>(null) }
    var selectedInvoiceForDetail by remember { mutableStateOf<Invoice?>(null) }
    var showPOSCheckoutDialog by remember { mutableStateOf(false) }
    var showChangePasswordDialog by remember { mutableStateOf(false) }
    
    // Quick barcode search state for scanner simulation
    var showBarcodeScannerSim by remember { mutableStateOf(false) }

    // Toast Notification Banner
    LaunchedEffect(viewModel.toastMessage) {
        viewModel.toastMessage?.let {
            kotlinx.coroutines.delay(3000)
            viewModel.clearToast()
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        if (viewModel.currentUser == null) {
            // --- LOGIN SCREEN ---
            LoginScreen(viewModel)
        } else {
            // --- MAIN APPLICATION INTERFACE ---
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Default.LocalPharmacy,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.secondary,
                                    modifier = Modifier.size(28.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    "نظام إدارة الصيدلية",
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimary
                                )
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            titleContentColor = MaterialTheme.colorScheme.onPrimary
                        ),
                        actions = {
                            // User Info Box
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(MaterialTheme.colorScheme.primaryContainer)
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                                    .clickable { showChangePasswordDialog = true },
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Default.Person,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Column {
                                    Text(
                                        viewModel.currentUser?.fullName ?: "",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                    Text(
                                        if (viewModel.currentUser?.role == "ADMIN") "مدير النظام" else "موظف صيدلي",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f)
                                    )
                                }
                            }
                            IconButton(onClick = { viewModel.logout() }) {
                                Icon(
                                    Icons.Default.Logout,
                                    contentDescription = "تسجيل الخروج",
                                    tint = MaterialTheme.colorScheme.onPrimary
                                )
                            }
                        }
                    )
                },
                bottomBar = {
                    PharmacyBottomNav(
                        currentScreen = viewModel.currentScreen,
                        onScreenSelected = { viewModel.currentScreen = it }
                    )
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .background(MaterialTheme.colorScheme.background)
                ) {
                    when (viewModel.currentScreen) {
                        "dashboard" -> DashboardScreen(
                            viewModel = viewModel,
                            products = products,
                            companies = companies,
                            invoices = invoices,
                            lowStockList = lowStockList
                        )
                        "pos" -> POSScreen(
                            viewModel = viewModel,
                            products = products,
                            onScanClick = { showBarcodeScannerSim = true },
                            onCheckoutClick = { showPOSCheckoutDialog = true }
                        )
                        "inventory" -> InventoryScreen(
                            viewModel = viewModel,
                            products = products,
                            companies = companies,
                            onAddProductClick = { showAddProductDialog = true },
                            onEditProductClick = { productToEdit = it }
                        )
                        "companies" -> CompaniesScreen(
                            viewModel = viewModel,
                            companies = companies,
                            onAddCompanyClick = { showAddCompanyDialog = true },
                            onEditCompanyClick = { companyToEdit = it }
                        )
                        "invoices" -> InvoicesScreen(
                            viewModel = viewModel,
                            invoices = invoices,
                            onInvoiceClick = { selectedInvoiceForDetail = it }
                        )
                        "reports" -> ReportsScreen(
                            products = products,
                            invoices = invoices,
                            viewModel = viewModel
                        )
                        "settings" -> SettingsScreen(
                            viewModel = viewModel,
                            onPasswordChangeClick = { showChangePasswordDialog = true }
                        )
                    }
                }
            }
        }

        // --- Custom Overlay Toast ---
        viewModel.toastMessage?.let { message ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = 90.dp, start = 16.dp, end = 16.dp),
                contentAlignment = Alignment.BottomCenter
            ) {
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.inverseSurface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
                ) {
                    Text(
                        text = message,
                        color = MaterialTheme.colorScheme.inverseOnSurface,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp),
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        // --- Dialogs ---
        if (showAddProductDialog) {
            ProductFormDialog(
                companies = companies,
                onDismiss = { showAddProductDialog = false },
                onSave = { prod ->
                    viewModel.addProduct(prod)
                    showAddProductDialog = false
                }
            )
        }

        productToEdit?.let { product ->
            ProductFormDialog(
                product = product,
                companies = companies,
                onDismiss = { productToEdit = null },
                onSave = { prod ->
                    viewModel.updateProduct(prod)
                    productToEdit = null
                },
                onDelete = { prod ->
                    viewModel.deleteProduct(prod)
                    productToEdit = null
                }
            )
        }

        if (showAddCompanyDialog) {
            CompanyFormDialog(
                onDismiss = { showAddCompanyDialog = false },
                onSave = { comp ->
                    viewModel.addCompany(comp)
                    showAddCompanyDialog = false
                }
            )
        }

        companyToEdit?.let { company ->
            CompanyFormDialog(
                company = company,
                onDismiss = { companyToEdit = null },
                onSave = { comp ->
                    viewModel.updateCompany(comp)
                    companyToEdit = null
                },
                onDelete = { comp ->
                    viewModel.deleteCompany(comp)
                    companyToEdit = null
                }
            )
        }

        selectedInvoiceForDetail?.let { invoice ->
            InvoiceDetailDialog(
                invoice = invoice,
                viewModel = viewModel,
                onDismiss = { selectedInvoiceForDetail = null }
            )
        }

        if (showPOSCheckoutDialog) {
            CheckoutPOSDialog(
                viewModel = viewModel,
                onDismiss = { showPOSCheckoutDialog = false },
                onCheckoutSuccess = {
                    showPOSCheckoutDialog = false
                }
            )
        }

        if (showChangePasswordDialog) {
            ChangePasswordDialog(
                viewModel = viewModel,
                onDismiss = { showChangePasswordDialog = false }
            )
        }

        if (showBarcodeScannerSim) {
            BarcodeScannerSimDialog(
                products = products,
                onDismiss = { showBarcodeScannerSim = false },
                onBarcodeScanned = { barcode ->
                    viewModel.scanBarcodeAndAdd(barcode)
                    showBarcodeScannerSim = false
                }
            )
        }
    }
}

// ==================== BOTTOM NAVIGATION ====================
@Composable
fun PharmacyBottomNav(
    currentScreen: String,
    onScreenSelected: (String) -> Unit
) {
    val items = listOf(
        Triple("dashboard", "لوحة التحكم", Icons.Default.Dashboard),
        Triple("pos", "نقاط البيع", Icons.Default.PointOfSale),
        Triple("inventory", "المخزن", Icons.Default.Inventory),
        Triple("companies", "الشركات", Icons.Default.Business),
        Triple("invoices", "الفواتير", Icons.Default.ReceiptLong),
        Triple("reports", "التقارير", Icons.Default.Assessment),
        Triple("settings", "النسخ والإعدادات", Icons.Default.Settings)
    )

    NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp,
        windowInsets = WindowInsets.navigationBars
    ) {
        items.forEach { (route, label, icon) ->
            NavigationBarItem(
                selected = currentScreen == route,
                onClick = { onScreenSelected(route) },
                icon = { Icon(icon, contentDescription = label) },
                label = { 
                    Text(
                        text = label, 
                        fontSize = 11.sp, 
                        maxLines = 1,
                        fontWeight = if (currentScreen == route) FontWeight.Bold else FontWeight.Normal
                    ) 
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = MaterialTheme.colorScheme.primary,
                    selectedTextColor = MaterialTheme.colorScheme.primary,
                    indicatorColor = MaterialTheme.colorScheme.primaryContainer
                ),
                modifier = Modifier.testTag("nav_tab_$route")
            )
        }
    }
}

// ==================== LOGIN SCREEN ====================
@Composable
fun LoginScreen(viewModel: PharmacyViewModel) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        MaterialTheme.colorScheme.primary,
                        MaterialTheme.colorScheme.primaryContainer,
                        MaterialTheme.colorScheme.background
                    )
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .padding(16.dp),
            shape = RoundedCornerShape(24.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 12.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.LocalPharmacy,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(48.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "نظام إدارة الصيدلية",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    textAlign = TextAlign.Center
                )

                Text(
                    text = "يرجى تسجيل الدخول لمتابعة العمليات",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp),
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(24.dp))

                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it },
                    label = { Text("اسم المستخدم") },
                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("login_username_input"),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("كلمة المرور") },
                    leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                    trailingIcon = {
                        IconButton(onClick = { passwordVisible = !passwordVisible }) {
                            Icon(
                                imageVector = if (passwordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                contentDescription = if (passwordVisible) "إخفاء" else "إظهار"
                            )
                        }
                    },
                    visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("login_password_input"),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = {
                        viewModel.login(username, password)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("login_button"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Login, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("تسجيل الدخول", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(24.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.Info,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                "بيانات تجريبية سريعة للتجربة:",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "المدير (صلاحيات كاملة):\nاسم المستخدم: admin | كلمة المرور: 123456",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "الموظف (مبيعات ومخزن):\nاسم المستخدم: staff | كلمة المرور: 123456",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

// ==================== DASHBOARD SCREEN ====================
@Composable
fun DashboardScreen(
    viewModel: PharmacyViewModel,
    products: List<Product>,
    companies: List<Company>,
    invoices: List<Invoice>,
    lowStockList: List<Product>
) {
    val totalItemsCount = products.size
    val totalCompaniesCount = companies.size
    val totalInventoryValue = products.sumOf { it.purchasePrice * it.quantity }
    val expiredProducts = products.filter { viewModel.isExpired(it.expirationDate) }
    val expiredCount = expiredProducts.size
    val nearExpiryCount = products.count { viewModel.isNearExpiry(it.expirationDate) }
    val lowStockCount = lowStockList.size
    val totalSalesValue = invoices.sumOf { it.total }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(20.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "أهلاً بك مجدداً، ${viewModel.currentUser?.fullName ?: ""}",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            text = "نظرة عامة على حالة الصيدلية والمخزون اليوم",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                        )
                    }
                    Icon(
                        Icons.Default.MedicalServices,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(56.dp)
                    )
                }
            }
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    StatCard(
                        title = "إجمالي الأصناف",
                        value = "$totalItemsCount دواء",
                        icon = Icons.Default.MedicalInformation,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        title = "عدد الموردين",
                        value = "$totalCompaniesCount شركة",
                        icon = Icons.Default.Business,
                        color = MaterialTheme.colorScheme.tertiary,
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    StatCard(
                        title = "قيمة المخزون شراء",
                        value = totalInventoryValue.formatIqd(),
                        icon = Icons.Default.AccountBalanceWallet,
                        color = Color(0xFFE65100),
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        title = "إجمالي المبيعات",
                        value = totalSalesValue.formatIqd(),
                        icon = Icons.Default.TrendingUp,
                        color = Color(0xFF2E7D32),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        if (expiredCount > 0 || nearExpiryCount > 0 || lowStockCount > 0) {
            item {
                Text(
                    text = "تنبيهات هامة تحتاج متابعة فورية",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (expiredCount > 0) {
                        AlertQuickCard(
                            label = "أدوية منتهية",
                            count = "$expiredCount",
                            color = MaterialTheme.colorScheme.error,
                            icon = Icons.Default.Cancel,
                            modifier = Modifier.weight(1f),
                            onClick = { viewModel.currentScreen = "inventory" }
                        )
                    }
                    if (nearExpiryCount > 0) {
                        AlertQuickCard(
                            label = "قرب الانتهاء",
                            count = "$nearExpiryCount",
                            color = Color(0xFFF57C00),
                            icon = Icons.Default.WarningAmber,
                            modifier = Modifier.weight(1f),
                            onClick = { viewModel.currentScreen = "inventory" }
                        )
                    }
                    if (lowStockCount > 0) {
                        AlertQuickCard(
                            label = "كميات منخفضة",
                            count = "$lowStockCount",
                            color = Color(0xFFFBC02D),
                            icon = Icons.Default.TrendingDown,
                            modifier = Modifier.weight(1f),
                            onClick = { viewModel.currentScreen = "inventory" }
                        )
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "آخر عمليات البيع (POS)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                TextButton(onClick = { viewModel.currentScreen = "invoices" }) {
                    Text("عرض الكل")
                }
            }
        }

        if (invoices.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                Icons.Default.Receipt,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                                modifier = Modifier.size(40.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                "لا توجد عمليات بيع مسجلة حتى الآن",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        } else {
            items(invoices.take(5)) { invoice ->
                val sdf = SimpleDateFormat("yyyy-MM-dd hh:mm a", Locale.getDefault())
                val dateString = sdf.format(Date(invoice.timestamp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                invoice.invoiceNumber,
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.bodyLarge
                            )
                            Text(
                                dateString,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                "البائع: ${invoice.soldBy}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                invoice.total.formatIqd(),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color(0xFFE8F5E9))
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    "مدفوع نقداً",
                                    fontSize = 11.sp,
                                    color = Color(0xFF2E7D32),
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StatCard(
    title: String,
    value: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = value,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(24.dp))
            }
        }
    }
}

@Composable
fun AlertQuickCard(
    label: String,
    count: String,
    color: Color,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier.clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.1f)),
        border = BorderStroke(1.dp, color.copy(alpha = 0.3f)),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                count,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = color
            )
            Text(
                label,
                style = MaterialTheme.typography.bodySmall,
                color = color,
                maxLines = 1,
                textAlign = TextAlign.Center
            )
        }
    }
}

// ==================== POS SCREEN ====================
fun Double.formatIqd(): String {
    return String.format(Locale.US, "%,.0f د.ع", this)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun POSScreen(
    viewModel: PharmacyViewModel,
    products: List<Product>,
    onScanClick: () -> Unit,
    onCheckoutClick: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("الكل") }
    
    // Dialog states
    var showPrinterDialog by remember { mutableStateOf(false) }
    var showReceiptDialog by remember { mutableStateOf(false) }
    
    // Live Arabic Date & Time Clock
    var currentDateTime by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        val formatter = SimpleDateFormat("yyyy/MM/dd - hh:mm:ss a", Locale("ar"))
        while (true) {
            currentDateTime = formatter.format(Date())
            kotlinx.coroutines.delay(1000)
        }
    }

    val filteredProducts = products.filter { prod ->
        val matchesSearch = prod.tradeName.contains(searchQuery, ignoreCase = true) ||
                prod.scientificName.contains(searchQuery, ignoreCase = true) ||
                prod.barcode.contains(searchQuery, ignoreCase = true)
        val matchesCategory = selectedCategory == "الكل" || prod.category == selectedCategory
        matchesSearch && matchesCategory
    }

    val categories = listOf("الكل") + products.map { it.category }.distinct()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // --- 1. Top Sub-Header Section (Pharmacy Name, User, Time, Printer Status) ---
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Right: Pharmacy info & Cashier
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.LocalPharmacy,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            "صيدلية النخبة التجارية",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Person,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            "المستخدم: ${viewModel.currentUser?.fullName ?: "غير معروف"}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Center: Live clock
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Icon(
                        Icons.Default.Schedule,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        currentDateTime,
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                // Left: Bluetooth Printer Status Chip
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(
                            if (viewModel.isBluetoothConnected) Color(0xFFE8F5E9)
                            else MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f)
                        )
                        .border(
                            1.dp,
                            if (viewModel.isBluetoothConnected) Color(0xFF81C784)
                            else MaterialTheme.colorScheme.error.copy(alpha = 0.5f),
                            RoundedCornerShape(20.dp)
                        )
                        .clickable { showPrinterDialog = true }
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        if (viewModel.isBluetoothConnected) Icons.Default.BluetoothConnected
                        else Icons.Default.Bluetooth,
                        contentDescription = "Bluetooth طابعة",
                        tint = if (viewModel.isBluetoothConnected) Color(0xFF2E7D32) else MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        if (viewModel.isBluetoothConnected) "طابعة متصلة: ${viewModel.selectedBluetoothPrinter}"
                        else "ربط طابعة Bluetooth 🔴",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (viewModel.isBluetoothConnected) Color(0xFF1B5E20) else MaterialTheme.colorScheme.error
                    )
                }
            }
        }

        // --- 2. Responsive Main Layout Container (BoxWithConstraints) ---
        BoxWithConstraints(modifier = Modifier.weight(1f).fillMaxWidth()) {
            val isCompact = maxWidth < 750.dp

            if (isCompact) {
                // Phone view: Stacked tabs layout to fit everything without overflow
                var selectedTab by remember { mutableStateOf(0) } // 0 = Products, 1 = Cart
                Column(modifier = Modifier.fillMaxSize()) {
                    TabRow(
                        selectedTabIndex = selectedTab,
                        containerColor = MaterialTheme.colorScheme.surface
                    ) {
                        Tab(
                            selected = selectedTab == 0,
                            onClick = { selectedTab = 0 },
                            text = {
                                Text(
                                    "الأدوية المتاحة (${filteredProducts.size})",
                                    fontWeight = FontWeight.Bold
                                )
                            },
                            icon = { Icon(Icons.Default.MedicalServices, contentDescription = null) }
                        )
                        Tab(
                            selected = selectedTab == 1,
                            onClick = { selectedTab = 1 },
                            text = {
                                Text(
                                    "سلة البيع (${viewModel.cart.value.size})",
                                    fontWeight = FontWeight.Bold
                                )
                            },
                            icon = {
                                BadgedBox(badge = {
                                    if (viewModel.cart.value.isNotEmpty()) {
                                        Badge { Text("${viewModel.cart.value.size}") }
                                    }
                                }) {
                                    Icon(Icons.Default.ShoppingCart, contentDescription = null)
                                }
                            }
                        )
                    }

                    Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                        if (selectedTab == 0) {
                            POSProductsSection(
                                viewModel = viewModel,
                                searchQuery = searchQuery,
                                onSearchQueryChange = { searchQuery = it },
                                selectedCategory = selectedCategory,
                                onCategoryChange = { selectedCategory = it },
                                categories = categories,
                                filteredProducts = filteredProducts,
                                onScanClick = onScanClick
                            )
                        } else {
                            POSCartSection(
                                viewModel = viewModel,
                                onCheckoutClick = onCheckoutClick,
                                onPrintClick = { showReceiptDialog = true }
                            )
                        }
                    }
                }
            } else {
                // Tablet/Wide view: Split side-by-side layout
                Row(modifier = Modifier.fillMaxSize()) {
                    // Right side (RTL): Active Sale Cart Column
                    Column(
                        modifier = Modifier
                            .weight(0.44f)
                            .fillMaxHeight()
                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                    ) {
                        POSCartSection(
                            viewModel = viewModel,
                            onCheckoutClick = onCheckoutClick,
                            onPrintClick = { showReceiptDialog = true }
                        )
                    }

                    // Left side (RTL): Medicines Search & Products Grid
                    Column(
                        modifier = Modifier
                            .weight(0.56f)
                            .fillMaxHeight()
                    ) {
                        POSProductsSection(
                            viewModel = viewModel,
                            searchQuery = searchQuery,
                            onSearchQueryChange = { searchQuery = it },
                            selectedCategory = selectedCategory,
                            onCategoryChange = { selectedCategory = it },
                            categories = categories,
                            filteredProducts = filteredProducts,
                            onScanClick = onScanClick
                        )
                    }
                }
            }
        }
    }

    // --- Bluetooth Printer Picker Dialog ---
    if (showPrinterDialog) {
        BluetoothPrinterDialog(
            viewModel = viewModel,
            onDismiss = { showPrinterDialog = false }
        )
    }

    // --- Thermal Receipt Print Preview Dialog ---
    if (showReceiptDialog) {
        ReceiptPrintPreviewDialog(
            viewModel = viewModel,
            onDismiss = { showReceiptDialog = false }
        )
    }
}

@Composable
fun POSProductsSection(
    viewModel: PharmacyViewModel,
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    selectedCategory: String,
    onCategoryChange: (String) -> Unit,
    categories: List<String>,
    filteredProducts: List<Product>,
    onScanClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Search and barcode scanner buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchQueryChange,
                placeholder = { Text("ابحث باسم الدواء، المادة الفعالة أو الباركود...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchQueryChange("") }) {
                            Icon(Icons.Default.Clear, contentDescription = "مسح")
                        }
                    }
                },
                modifier = Modifier
                    .weight(1f)
                    .testTag("pos_search_input"),
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surface
                )
            )

            // Direct Scan Barcode Button
            Button(
                onClick = onScanClick,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.height(56.dp)
            ) {
                Icon(Icons.Default.QrCodeScanner, contentDescription = "فتح الكاميرا لقراءة الباركود")
                Spacer(modifier = Modifier.width(6.dp))
                Text("مسح باركود", fontWeight = FontWeight.Bold)
            }
        }

        // Categories filter pills
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(vertical = 4.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(categories) { cat ->
                val isSelected = cat == selectedCategory
                FilterChip(
                    selected = isSelected,
                    onClick = { onCategoryChange(cat) },
                    label = { Text(cat) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primary,
                        selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    shape = RoundedCornerShape(12.dp)
                )
            }
        }

        // Medicines Grid
        if (filteredProducts.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(
                        Icons.Default.SearchOff,
                        contentDescription = null,
                        modifier = Modifier.size(64.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f)
                    )
                    Text(
                        "لا توجد أدوية مطابقة للبحث الحالي",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodyLarge
                    )
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(165.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 16.dp)
            ) {
                items(filteredProducts) { prod ->
                    POSProductCard(prod, viewModel)
                }
            }
        }
    }
}

@Composable
fun POSCartSection(
    viewModel: PharmacyViewModel,
    onCheckoutClick: () -> Unit,
    onPrintClick: () -> Unit
) {
    val cartList = viewModel.cart.value

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.surface)
    ) {
        // Cart Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f))
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Default.ShoppingCart,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    "قائمة المبيعات النشطة",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            Text(
                "${cartList.size} أصناف",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer)
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            )
        }

        // Cart items scrollable column
        if (cartList.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        Icons.Default.AddShoppingCart,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.25f),
                        modifier = Modifier.size(64.dp)
                    )
                    Text(
                        "السلة فارغة حالياً",
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                    )
                    Text(
                        "اضغط على أي دواء من اليسار أو امسح الباركود",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(cartList) { item ->
                    POSCartItemRow(item, viewModel)
                }
            }
        }

        // Bottom Calculation Panel
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.background),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("المجموع الفرعي:", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        viewModel.getCartSubtotal().formatIqd(),
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.bodyLarge
                    )
                }
                
                // Active Interactive Discount Selector inside Cart Column
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("الخصم الممنوح:", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .padding(horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            IconButton(
                                onClick = { if (viewModel.discountPercent > 0) viewModel.discountPercent -= 5.0 },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(Icons.Default.Remove, contentDescription = "تقليل الخصم", modifier = Modifier.size(14.dp))
                            }
                            Text(
                                "${viewModel.discountPercent.toInt()}%",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold
                            )
                            IconButton(
                                onClick = { if (viewModel.discountPercent < 100) viewModel.discountPercent += 5.0 },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = "زيادة الخصم", modifier = Modifier.size(14.dp))
                            }
                        }
                    }
                    if (viewModel.discountPercent > 0) {
                        Text(
                            "- ${viewModel.getCartDiscountAmount().formatIqd()}",
                            color = MaterialTheme.colorScheme.error,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.bodyLarge
                        )
                    } else {
                        Text("0 د.ع", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("ضريبة القيمة المضافة (15%):", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        viewModel.getCartTaxAmount().formatIqd(),
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }

                Divider(modifier = Modifier.padding(vertical = 4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "الإجمالي النهائي الكلي:",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        viewModel.getCartTotal().formatIqd(),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        // Action Buttons Row (Pay, Print, Save, Clear)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // First Row: Print Receipt and Direct Save Draft
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // print receipt
                OutlinedButton(
                    onClick = onPrintClick,
                    enabled = cartList.isNotEmpty(),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.primary),
                    border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary)
                ) {
                    Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("طباعة الفاتورة", fontWeight = FontWeight.Bold)
                }

                // direct save
                OutlinedButton(
                    onClick = {
                        if (cartList.isNotEmpty()) {
                            // Automatically fill full paid amount to check out directly
                            viewModel.cashPaidAmount = viewModel.getCartTotal()
                            val ok = viewModel.checkoutCart()
                        }
                    },
                    enabled = cartList.isNotEmpty(),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF2E7D32)),
                    border = BorderStroke(1.5.dp, Color(0xFF2E7D32))
                ) {
                    Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("حفظ سريع", fontWeight = FontWeight.Bold)
                }
            }

            // Second Row: Big Pay Button + Clear Cart
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(
                    onClick = { viewModel.clearCart() },
                    modifier = Modifier
                        .size(54.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.errorContainer),
                    colors = IconButtonDefaults.iconButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) {
                    Icon(Icons.Default.Delete, contentDescription = "مسح السلة بالكامل")
                }

                Button(
                    onClick = onCheckoutClick,
                    enabled = cartList.isNotEmpty(),
                    modifier = Modifier
                        .weight(1f)
                        .height(54.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Icon(Icons.Default.Payment, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("دفع وحفظ الفاتورة", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun POSProductCard(product: Product, viewModel: PharmacyViewModel) {
    val isLowStock = product.quantity <= product.lowStockLimit
    val isOutOfStock = product.quantity == 0
    val isExpired = viewModel.isExpired(product.expirationDate)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = !isOutOfStock) { viewModel.addToCart(product) },
        colors = CardDefaults.cardColors(
            containerColor = if (isOutOfStock) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            else MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = if (isExpired) BorderStroke(1.5.dp, MaterialTheme.colorScheme.error)
        else if (isLowStock) BorderStroke(1.5.dp, Color(0xFFFFA000))
        else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            // Category Badge & Expiry Alert
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        product.category,
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                }
                
                if (isExpired) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(MaterialTheme.colorScheme.errorContainer)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            "منتهي الصلاحية!",
                            fontSize = 8.sp,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(6.dp))
            
            // Product Names
            Text(
                product.tradeName,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.bodyMedium,
                maxLines = 1,
                color = if (isOutOfStock) MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f) else MaterialTheme.colorScheme.onSurface
            )
            Text(
                product.scientificName,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                maxLines = 1
            )
            
            Spacer(modifier = Modifier.height(10.dp))

            // Pricing and Qty Badge Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    product.salePrice.formatIqd(),
                    fontWeight = FontWeight.Black,
                    color = MaterialTheme.colorScheme.primary,
                    fontSize = 13.sp
                )
                
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            if (isOutOfStock) MaterialTheme.colorScheme.errorContainer
                            else if (isLowStock) Color(0xFFFFF9C4)
                            else Color(0xFFE8F5E9)
                        )
                        .padding(horizontal = 6.dp, vertical = 3.dp)
                ) {
                    Text(
                        if (isOutOfStock) "نفذت الكمية!" else "متوفر: ${product.quantity}",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isOutOfStock) MaterialTheme.colorScheme.onErrorContainer
                        else if (isLowStock) Color(0xFFF57F17)
                        else Color(0xFF2E7D32)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Explicit Add Button to satisfy the 48dp touch target
            Button(
                onClick = { viewModel.addToCart(product) },
                enabled = !isOutOfStock && !isExpired,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(36.dp),
                contentPadding = PaddingValues(0.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("إضافة للسلة", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun POSCartItemRow(item: CartItem, viewModel: PharmacyViewModel) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Product info
            Column(modifier = Modifier.weight(1f)) {
                Text(item.product.tradeName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(
                    "${item.product.salePrice.formatIqd()} / حبة",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Qty controllers
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                IconButton(
                    onClick = { viewModel.updateCartQuantity(item.product, item.quantity - 1) },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        Icons.Default.RemoveCircleOutline,
                        contentDescription = "تقليل",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Text(
                    text = "${item.quantity}",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.bodyMedium
                )
                IconButton(
                    onClick = { viewModel.updateCartQuantity(item.product, item.quantity + 1) },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        Icons.Default.AddCircleOutline,
                        contentDescription = "زيادة",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(10.dp))

            // Total for item
            Text(
                (item.product.salePrice * item.quantity).formatIqd(),
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.primary
            )

            Spacer(modifier = Modifier.width(6.dp))

            // Trashcan remove
            IconButton(
                onClick = { viewModel.removeFromCart(item.product) },
                modifier = Modifier.size(32.dp)
            ) {
                Icon(
                    Icons.Default.Delete,
                    contentDescription = "حذف",
                    tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
fun BluetoothPrinterDialog(
    viewModel: PharmacyViewModel,
    onDismiss: () -> Unit
) {
    var isScanning by remember { mutableStateOf(false) }
    
    // Simulate Discovery Scans
    LaunchedEffect(isScanning) {
        if (isScanning) {
            kotlinx.coroutines.delay(2000)
            isScanning = false
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .wrapContentHeight(),
            shape = RoundedCornerShape(24.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "إدارة طابعات البلوتوث",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Clear, contentDescription = "إغلاق")
                    }
                }

                Divider()

                Text(
                    "اختر طابعة الفواتير الحرارية الصغيرة (58mm/80mm) للاتصال بها والطباعة مباشرة:",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                // Current Connected Printer Banner
                if (viewModel.isBluetoothConnected) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFFE8F5E9))
                            .border(1.dp, Color(0xFF81C784), RoundedCornerShape(12.dp))
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.BluetoothConnected, contentDescription = null, tint = Color(0xFF2E7D32))
                            Column {
                                Text("متصل حالياً بـ:", style = MaterialTheme.typography.bodySmall, color = Color(0xFF1B5E20))
                                Text(viewModel.selectedBluetoothPrinter ?: "", fontWeight = FontWeight.Bold, color = Color(0xFF1B5E20))
                            }
                        }
                        OutlinedButton(
                            onClick = { viewModel.disconnectPrinter() },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.error),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Text("قطع الاتصال", fontSize = 11.sp)
                        }
                    }
                } else {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Bluetooth, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("لا توجد طابعة متصلة حالياً. الرجاء الربط بالأسفل.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("الطابعات المتاحة بالمحيط:", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                    
                    if (isScanning) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                    } else {
                        TextButton(onClick = { isScanning = true }) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("تحديث البحث")
                        }
                    }
                }

                // Discovered Printers List
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    viewModel.bluetoothDevices.forEach { device ->
                        val isCurrent = viewModel.selectedBluetoothPrinter == device
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    if (isCurrent) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                                    else MaterialTheme.colorScheme.surface
                                )
                                .border(
                                    1.dp,
                                    if (isCurrent) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f),
                                    RoundedCornerShape(12.dp)
                                )
                                .clickable {
                                    viewModel.connectToBluetoothPrinter(device)
                                }
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(
                                    Icons.Default.Print,
                                    tint = if (isCurrent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                    contentDescription = null
                                )
                                Column {
                                    Text(device, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                    Text("طابعة حرارية بلوتوث Esc/Pos", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                            if (isCurrent) {
                                Icon(Icons.Default.CheckCircle, contentDescription = "متصل", tint = Color(0xFF2E7D32))
                            } else {
                                Icon(Icons.Default.ChevronLeft, contentDescription = "اتصال", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                
                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("إتمام الإعدادات")
                }
            }
        }
    }
}

@Composable
fun ReceiptPrintPreviewDialog(
    viewModel: PharmacyViewModel,
    onDismiss: () -> Unit
) {
    var isPrinting by remember { mutableStateOf(false) }
    var printFinished by remember { mutableStateOf(false) }
    
    val cartItems = viewModel.cart.value
    val subtotal = viewModel.getCartSubtotal()
    val discount = viewModel.getCartDiscountAmount()
    val tax = viewModel.getCartTaxAmount()
    val total = viewModel.getCartTotal()
    val formattedDate = SimpleDateFormat("yyyy-MM-dd hh:mm a", Locale.US).format(Date())
    val simulatedInvoiceNum = "INV-${System.currentTimeMillis() % 1000000}"

    LaunchedEffect(isPrinting) {
        if (isPrinting) {
            kotlinx.coroutines.delay(2000) // Printing simulation feed
            isPrinting = false
            printFinished = true
            viewModel.showToast("تمت الطباعة بنجاح على ${viewModel.selectedBluetoothPrinter ?: "الطابعة الافتراضية"}!")
            // Automatically checkout after success print to save
            viewModel.cashPaidAmount = total
            viewModel.checkoutCart()
            onDismiss()
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.9f),
            shape = RoundedCornerShape(24.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 12.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                // Dialog Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.Print, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Text("معاينة الفاتورة قبل الطباعة", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Clear, contentDescription = "إغلاق")
                    }
                }

                Divider(modifier = Modifier.padding(vertical = 8.dp))

                // Scrollable 58mm Thermal Receipt Simulation Paper (White thermal sheet)
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFFF9F9F9))
                        .border(1.dp, Color(0xFFE0E0E0), RoundedCornerShape(12.dp))
                        .padding(horizontal = 8.dp, vertical = 12.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState()),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Jagged visual torn top
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                            Text("▲▼▲▼▲▼▲▼▲▼▲▼▲▼▲▼▲▼▲▼▲▼▲▼▲▼▲▼", color = Color.Gray, fontSize = 10.sp, letterSpacing = 2.sp)
                        }

                        // Receipt Paper Sheet Content (White paper feel)
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp, horizontal = 4.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                // Store Banner
                                Text(
                                    "صيدلية النخبة التجارية",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Black,
                                    color = Color.Black
                                )
                                Text(
                                    "بغداد - المنصور - شارع 14 رمضان",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.DarkGray
                                )
                                Text(
                                    "هاتف: 07701234567",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.DarkGray
                                )
                                
                                Text("----------------------------------------", color = Color.Gray, modifier = Modifier.padding(vertical = 4.dp))
                                
                                // Invoice metadata
                                Text(
                                    "فاتورة مبيعات نقدية",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Black
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("رقم الفاتورة:", style = MaterialTheme.typography.bodySmall, color = Color.DarkGray)
                                    Text(simulatedInvoiceNum, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = Color.Black)
                                }
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("التاريخ:", style = MaterialTheme.typography.bodySmall, color = Color.DarkGray)
                                    Text(formattedDate, style = MaterialTheme.typography.bodySmall, color = Color.Black)
                                }
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("البائع:", style = MaterialTheme.typography.bodySmall, color = Color.DarkGray)
                                    Text(viewModel.currentUser?.fullName ?: "مدير الصيدلية", style = MaterialTheme.typography.bodySmall, color = Color.Black)
                                }

                                Text("----------------------------------------", color = Color.Gray, modifier = Modifier.padding(vertical = 4.dp))

                                // Items Header Row
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("الصنف", modifier = Modifier.weight(1.5f), fontWeight = FontWeight.Bold, color = Color.Black, fontSize = 12.sp)
                                    Text("الكمية", modifier = Modifier.weight(0.7f), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, color = Color.Black, fontSize = 12.sp)
                                    Text("السعر", modifier = Modifier.weight(1f), textAlign = TextAlign.Left, fontWeight = FontWeight.Bold, color = Color.Black, fontSize = 12.sp)
                                    Text("الإجمالي", modifier = Modifier.weight(1.2f), textAlign = TextAlign.Left, fontWeight = FontWeight.Bold, color = Color.Black, fontSize = 12.sp)
                                }
                                Divider(modifier = Modifier.padding(vertical = 4.dp), color = Color.LightGray)

                                // Cart Items Listing
                                cartItems.forEach { item ->
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text(item.product.tradeName, modifier = Modifier.weight(1.5f), color = Color.Black, fontSize = 11.sp, maxLines = 1)
                                        Text("${item.quantity}", modifier = Modifier.weight(0.7f), textAlign = TextAlign.Center, color = Color.Black, fontSize = 11.sp)
                                        Text(item.product.salePrice.formatIqd(), modifier = Modifier.weight(1f), textAlign = TextAlign.Left, color = Color.Black, fontSize = 11.sp)
                                        Text((item.product.salePrice * item.quantity).formatIqd(), modifier = Modifier.weight(1.2f), textAlign = TextAlign.Left, color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }

                                Text("----------------------------------------", color = Color.Gray, modifier = Modifier.padding(vertical = 4.dp))

                                // Financial summaries
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("المجموع الفرعي:", style = MaterialTheme.typography.bodySmall, color = Color.DarkGray)
                                    Text(subtotal.formatIqd(), style = MaterialTheme.typography.bodySmall, color = Color.Black)
                                }
                                if (discount > 0) {
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("الخصم الممنوح (${viewModel.discountPercent.toInt()}%):", style = MaterialTheme.typography.bodySmall, color = Color.Red)
                                        Text("- ${discount.formatIqd()}", style = MaterialTheme.typography.bodySmall, color = Color.Red, fontWeight = FontWeight.Bold)
                                    }
                                }
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("ضريبة القيمة المضافة (15%):", style = MaterialTheme.typography.bodySmall, color = Color.DarkGray)
                                    Text(tax.formatIqd(), style = MaterialTheme.typography.bodySmall, color = Color.Black)
                                }
                                
                                Divider(modifier = Modifier.padding(vertical = 4.dp), color = Color.LightGray)
                                
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Text("الإجمالي الكلي المطلوب:", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                                    Text(total.formatIqd(), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black, color = Color.Black)
                                }

                                Text("----------------------------------------", color = Color.Gray, modifier = Modifier.padding(vertical = 4.dp))

                                // Visual footer
                                Text("شكراً لزيارتكم صيدلية النخبة!", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = Color.Black)
                                Text("الأدوية المباعة لا ترد ولا تستبدل إلا خلال 3 أيام بموجب فاتورة الشراء", style = MaterialTheme.typography.labelSmall, color = Color.DarkGray, textAlign = TextAlign.Center)
                                
                                Spacer(modifier = Modifier.height(12.dp))
                                
                                // Simulated Barcode for scanning
                                BarcodeWidget(barcode = simulatedInvoiceNum, modifier = Modifier.height(40.dp).fillMaxWidth(0.8f))
                            }
                        }

                        // Jagged visual torn bottom
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                            Text("▲▼▲▼▲▼▲▼▲▼▲▼▲▼▲▼▲▼▲▼▲▼▲▼▲▼▲▼", color = Color.Gray, fontSize = 10.sp, letterSpacing = 2.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Bottom Print Action Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("إلغاء المعاينة")
                    }

                    Button(
                        onClick = { isPrinting = true },
                        modifier = Modifier.weight(1.5f),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        enabled = !isPrinting
                    ) {
                        if (isPrinting) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("جاري طباعة الفاتورة...")
                        } else {
                            Icon(
                                if (viewModel.isBluetoothConnected) Icons.Default.BluetoothConnected else Icons.Default.Print,
                                contentDescription = null
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                if (viewModel.isBluetoothConnected) "طباعة حرارية عبر Bluetooth"
                                else "طباعة تجريبية سريعة"
                            )
                        }
                    }
                }
            }
        }
    }
}

// ==================== INVENTORY SCREEN ====================
@Composable
fun InventoryScreen(
    viewModel: PharmacyViewModel,
    products: List<Product>,
    companies: List<Company>,
    onAddProductClick: () -> Unit,
    onEditProductClick: (Product) -> Unit
) {
    var filterType by remember { mutableStateOf("all") }
    
    val filteredProducts = products.filter {
        val matchesSearch = it.tradeName.contains(viewModel.productSearchQuery, ignoreCase = true) ||
                it.scientificName.contains(viewModel.productSearchQuery, ignoreCase = true) ||
                it.barcode.contains(viewModel.productSearchQuery, ignoreCase = true) ||
                it.category.contains(viewModel.productSearchQuery, ignoreCase = true)
        
        val matchesFilter = when (filterType) {
            "low_stock" -> it.quantity <= it.lowStockLimit
            "expiring" -> viewModel.isNearExpiry(it.expirationDate)
            "expired" -> viewModel.isExpired(it.expirationDate)
            else -> true
        }

        matchesSearch && matchesFilter
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = viewModel.productSearchQuery,
                onValueChange = { viewModel.productSearchQuery = it },
                label = { Text("ابحث باسم الدواء، المادة الفعالة، أو الباركود") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                modifier = Modifier.weight(1f),
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            Button(
                onClick = { onAddProductClick() },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.height(56.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(4.dp))
                Text("إضافة")
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val filters = listOf(
                Pair("all", "الكل (${products.size})"),
                Pair("low_stock", "قليل الكمية (${products.count { it.quantity <= it.lowStockLimit }})"),
                Pair("expiring", "قريب الانتهاء (${products.count { viewModel.isNearExpiry(it.expirationDate) }})"),
                Pair("expired", "منتهي الصلاحية (${products.count { viewModel.isExpired(it.expirationDate) }})")
            )

            filters.forEach { (type, label) ->
                FilterChip(
                    selected = filterType == type,
                    onClick = { filterType = type },
                    label = { Text(label, fontSize = 11.sp) }
                )
            }
        }

        if (filteredProducts.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.SearchOff,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier.size(56.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        "لا توجد أدوية مطابقة للخيارات المحددة",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filteredProducts) { product ->
                    InventoryProductRow(product, viewModel, onEditClick = { onEditProductClick(product) })
                }
            }
        }
    }
}

@Composable
fun InventoryProductRow(
    product: Product,
    viewModel: PharmacyViewModel,
    onEditClick: () -> Unit
) {
    val isExpired = viewModel.isExpired(product.expirationDate)
    val isNearExpiry = viewModel.isNearExpiry(product.expirationDate)
    val isLowStock = product.quantity <= product.lowStockLimit

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onEditClick() },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = if (isExpired) BorderStroke(1.5.dp, MaterialTheme.colorScheme.error)
        else if (isNearExpiry) BorderStroke(1.5.dp, Color(0xFFF57C00))
        else null
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        product.tradeName,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.bodyLarge
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    if (isExpired) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(MaterialTheme.colorScheme.errorContainer)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text("منتهي", fontSize = 10.sp, color = MaterialTheme.colorScheme.onErrorContainer, fontWeight = FontWeight.Bold)
                        }
                    } else if (isNearExpiry) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color(0xFFFFE0B2))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text("قريب الانتهاء", fontSize = 10.sp, color = Color(0xFFE65100), fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Text(
                    "الاسم العلمي: ${product.scientificName}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    "الشركة: ${product.manufacturerName} | القسم: ${product.category}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    "رقم التشغيلة (Batch): ${product.batchNumber} | تاريخ الانتهاء: ${product.expirationDate}",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (isExpired) MaterialTheme.colorScheme.error else if (isNearExpiry) Color(0xFFE65100) else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    product.salePrice.formatIqd(),
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    style = MaterialTheme.typography.bodyMedium
                )
                Text(
                    "شراء: ${product.purchasePrice.formatIqd()}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.Storage,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp),
                        tint = if (isLowStock) Color(0xFFF57F17) else Color(0xFF2E7D32)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        "${product.quantity} حبة",
                        fontWeight = FontWeight.Bold,
                        color = if (isLowStock) Color(0xFFF57F17) else Color(0xFF2E7D32),
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
}

// ==================== COMPANIES SCREEN ====================
@Composable
fun CompaniesScreen(
    viewModel: PharmacyViewModel,
    companies: List<Company>,
    onAddCompanyClick: () -> Unit,
    onEditCompanyClick: (Company) -> Unit
) {
    val filteredCompanies = companies.filter {
        it.name.contains(viewModel.companySearchQuery, ignoreCase = true) ||
        it.phone.contains(viewModel.companySearchQuery, ignoreCase = true) ||
        it.address.contains(viewModel.companySearchQuery, ignoreCase = true)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = viewModel.companySearchQuery,
                onValueChange = { viewModel.companySearchQuery = it },
                label = { Text("ابحث باسم شركة الأدوية أو رقم الهاتف") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                modifier = Modifier.weight(1f),
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            Button(
                onClick = { onAddCompanyClick() },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.height(56.dp)
            ) {
                Icon(Icons.Default.AddBusiness, contentDescription = null)
                Spacer(modifier = Modifier.width(4.dp))
                Text("إضافة")
            }
        }

        if (filteredCompanies.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "لا توجد شركات أدوية مسجلة حالياً بهذا الاسم",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filteredCompanies) { comp ->
                    CompanyRow(comp, onEditClick = { onEditCompanyClick(comp) })
                }
            }
        }
    }
}

@Composable
fun CompanyRow(company: Company, onEditClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onEditClick() },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    company.name,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                IconButton(onClick = onEditClick, modifier = Modifier.size(24.dp)) {
                    Icon(Icons.Default.Edit, contentDescription = "تعديل", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Phone, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.width(6.dp))
                Text(company.phone, style = MaterialTheme.typography.bodyMedium)
                Spacer(modifier = Modifier.width(20.dp))
                Icon(Icons.Default.Email, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.width(6.dp))
                Text(company.email, style = MaterialTheme.typography.bodyMedium)
            }
            Spacer(modifier = Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.LocationOn, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.width(6.dp))
                Text(company.address, style = MaterialTheme.typography.bodyMedium)
            }
            if (company.notes.isNotEmpty()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    "ملاحظات: ${company.notes}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

// ==================== INVOICES SCREEN ====================
@Composable
fun InvoicesScreen(
    viewModel: PharmacyViewModel,
    invoices: List<Invoice>,
    onInvoiceClick: (Invoice) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val filteredInvoices = invoices.filter {
        it.invoiceNumber.contains(searchQuery, ignoreCase = true) ||
        it.soldBy.contains(searchQuery, ignoreCase = true)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            label = { Text("بحث برقم الفاتورة أو اسم البائع") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            shape = RoundedCornerShape(12.dp)
        )

        if (filteredInvoices.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "لا توجد فواتير مبيعات مسجلة مطابقة للبحث",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filteredInvoices) { invoice ->
                    val sdf = SimpleDateFormat("yyyy-MM-dd hh:mm a", Locale.getDefault())
                    val dateString = sdf.format(Date(invoice.timestamp))
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onInvoiceClick(invoice) },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    invoice.invoiceNumber,
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    dateString,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    "البائع: ${invoice.soldBy}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    invoice.total.formatIqd(),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = Color(0xFF2E7D32),
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        "مكتملة",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color(0xFF2E7D32),
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==================== REPORTS SCREEN ====================
@Composable
fun ReportsScreen(
    products: List<Product>,
    invoices: List<Invoice>,
    viewModel: PharmacyViewModel
) {
    val totalSales = invoices.sumOf { it.total }
    val totalCost = products.sumOf { it.purchasePrice * it.quantity }
    val totalProfit = invoices.sumOf { invoice -> invoice.total * 0.18 }
    val expiredCount = products.count { viewModel.isExpired(it.expirationDate) }
    val nearExpiryCount = products.count { viewModel.isNearExpiry(it.expirationDate) }
    val lowStockCount = products.count { it.quantity <= it.lowStockLimit }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                "التقارير والإحصائيات المالية",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        "الملخص المالي العام",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        ReportValueItem("إجمالي المبيعات", totalSales.formatIqd(), Color(0xFF2E7D32))
                        ReportValueItem("الأرباح التقديرية", totalProfit.formatIqd(), Color(0xFF0288D1))
                        ReportValueItem("قيمة بضاعة المخزن", totalCost.formatIqd(), Color(0xFFE65100))
                    }
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "تقارير جرد المخزن وصلاحية الأدوية",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        ReportStatusBox("منتهي الصلاحية", "$expiredCount", MaterialTheme.colorScheme.error)
                        ReportStatusBox("قريب الانتهاء (60 يوم)", "$nearExpiryCount", Color(0xFFF57C00))
                        ReportStatusBox("ناقص ومطلوب فوراً", "$lowStockCount", Color(0xFFFBC02D))
                    }
                }
            }
        }

        item {
            Text(
                "الأدوية الأكثر مبيعاً ونشاطاً",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
        }

        if (products.isEmpty()) {
            item {
                Text("لا توجد أدوية لعرضها")
            }
        } else {
            val list = products.take(3)
            items(list) { prod ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(prod.tradeName, fontWeight = FontWeight.Bold)
                            Text(prod.scientificName, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("القسم: ${prod.category}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                "الأكثر مبيعاً",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF2E7D32),
                                fontWeight = FontWeight.Bold
                            )
                            Box(
                                modifier = Modifier
                                    .clip(CircleShape)
                                    .background(Color(0xFFE8F5E9))
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text("نشط جداً", fontSize = 11.sp, color = Color(0xFF2E7D32))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ReportValueItem(title: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(modifier = Modifier.height(4.dp))
        Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = color)
    }
}

@Composable
fun ReportStatusBox(title: String, count: String, color: Color) {
    Card(
        modifier = Modifier.width(100.dp),
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.08f)),
        border = BorderStroke(1.dp, color.copy(alpha = 0.3f))
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(count, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = color)
            Spacer(modifier = Modifier.height(4.dp))
            Text(title, style = MaterialTheme.typography.bodySmall, color = color, textAlign = TextAlign.Center, minLines = 2, maxLines = 2, fontSize = 10.sp)
        }
    }
}

// ==================== SETTINGS SCREEN ====================
@Composable
fun SettingsScreen(
    viewModel: PharmacyViewModel,
    onPasswordChangeClick: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                "النسخ الاحتياطي وإعدادات الصيدلية",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "إدارة الحساب والموظفين",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = { onPasswordChangeClick() },
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.LockReset, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("تغيير كلمة المرور")
                    }
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "النسخ الاحتياطي واسترجاع البيانات",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "لحفظ بيانات أدويتك ومبيعاتك وصيدليتك والوصول إليها بأمان دون اتصال بالإنترنت.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { viewModel.showToast("تم إنشاء نسخة احتياطية بنجاح: pharmacy_backup.sqlite") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.CloudUpload, contentDescription = null)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("نسخ احتياطي")
                        }

                        OutlinedButton(
                            onClick = { viewModel.showToast("تم استعادة نسخة قاعدة البيانات بنجاح") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.CloudDownload, contentDescription = null)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("استعادة")
                        }
                    }
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "تصدير التقارير وجرد المخزن",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { viewModel.showToast("تم تصدير جرد المخزن بنجاح: inventory_report.xlsx") },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.GridOn, contentDescription = null)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("تصدير Excel")
                        }

                        Button(
                            onClick = { viewModel.showToast("تم تصدير تقرير الأرباح والمبيعات بصيغة PDF") },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC62828)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.PictureAsPdf, contentDescription = null)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("تصدير PDF")
                        }
                    }
                }
            }
        }
    }
}

// ==================== DIALOGS IMPLEMENTATIONS ====================

@Composable
fun BarcodeWidget(barcode: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Canvas(
            modifier = Modifier
                .width(220.dp)
                .height(65.dp)
                .background(Color.White)
                .padding(horizontal = 8.dp, vertical = 6.dp)
        ) {
            val barCount = 45
            val barWidth = size.width / barCount
            val random = Random(barcode.hashCode().toLong())
            for (i in 0 until barCount) {
                if (i < 2 || i > barCount - 3) continue
                val isBlack = random.nextBoolean()
                if (isBlack) {
                    drawRect(
                        color = Color.Black,
                        topLeft = Offset(i * barWidth, 0f),
                        size = Size(barWidth * 0.75f, size.height)
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = barcode,
            style = MaterialTheme.typography.bodyMedium,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 2.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductFormDialog(
    product: Product? = null,
    companies: List<Company>,
    onDismiss: () -> Unit,
    onSave: (Product) -> Unit,
    onDelete: ((Product) -> Unit)? = null
) {
    var tradeName by remember { mutableStateOf(product?.tradeName ?: "") }
    var scientificName by remember { mutableStateOf(product?.scientificName ?: "") }
    var category by remember { mutableStateOf(product?.category ?: "مسكنات آلام") }
    var barcode by remember { mutableStateOf(product?.barcode ?: "") }
    var purchasePrice by remember { mutableStateOf(product?.purchasePrice?.toString() ?: "") }
    var salePrice by remember { mutableStateOf(product?.salePrice?.toString() ?: "") }
    var quantity by remember { mutableStateOf(product?.quantity?.toString() ?: "") }
    var productionDate by remember { mutableStateOf(product?.productionDate ?: "2025-01-01") }
    var expirationDate by remember { mutableStateOf(product?.expirationDate ?: "2027-01-01") }
    var batchNumber by remember { mutableStateOf(product?.batchNumber ?: "") }
    var lowStockLimit by remember { mutableStateOf(product?.lowStockLimit?.toString() ?: "10") }
    var notes by remember { mutableStateOf(product?.notes ?: "") }
    var showCameraScanner by remember { mutableStateOf(false) }

    var selectedCompanyId by remember { mutableStateOf(product?.manufacturerId ?: (companies.firstOrNull()?.id ?: 0)) }
    var companyDropdownExpanded by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f),
            shape = RoundedCornerShape(24.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                Text(
                    text = if (product == null) "إضافة دواء جديد للمخزن" else "تعديل بيانات الدواء",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = tradeName,
                        onValueChange = { tradeName = it },
                        label = { Text("الاسم التجاري (Commercial Name)") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = scientificName,
                        onValueChange = { scientificName = it },
                        label = { Text("الاسم العلمي (Active Ingredient)") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Box(modifier = Modifier.fillMaxWidth()) {
                        val currentCompName = companies.find { it.id == selectedCompanyId }?.name ?: "اختر الشركة المصنعة"
                        OutlinedTextField(
                            value = currentCompName,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("الشركة المصنعة") },
                            trailingIcon = {
                                IconButton(onClick = { companyDropdownExpanded = true }) {
                                    Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        )
                        DropdownMenu(
                            expanded = companyDropdownExpanded,
                            onDismissRequest = { companyDropdownExpanded = false }
                        ) {
                            companies.forEach { comp ->
                                DropdownMenuItem(
                                    text = { Text(comp.name) },
                                    onClick = {
                                        selectedCompanyId = comp.id
                                        companyDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = category,
                        onValueChange = { category = it },
                        label = { Text("التصنيف الطبي (مثال: مضاد حيوي)") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = barcode,
                            onValueChange = { barcode = it },
                            label = { Text("الباركود (Barcode)") },
                            modifier = Modifier.weight(1f)
                        )
                        
                        IconButton(
                            onClick = { showCameraScanner = true },
                            modifier = Modifier
                                .height(56.dp)
                                .width(56.dp)
                                .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(12.dp))
                        ) {
                            Icon(
                                Icons.Default.QrCodeScanner,
                                contentDescription = "قراءة الباركود بالكاميرا",
                                tint = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }

                        Button(
                            onClick = { barcode = (1000000000000..9999999999999).random().toString() },
                            modifier = Modifier.height(56.dp),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("توليد")
                        }
                    }

                    if (barcode.isNotEmpty()) {
                        Text("ملصق الباركود المتولد تلقائياً:", style = MaterialTheme.typography.labelSmall)
                        BarcodeWidget(barcode)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = purchasePrice,
                            onValueChange = { purchasePrice = it },
                            label = { Text("سعر الشراء") },
                            modifier = Modifier.weight(1f),
                            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number)
                        )
                        OutlinedTextField(
                            value = salePrice,
                            onValueChange = { salePrice = it },
                            label = { Text("سعر البيع") },
                            modifier = Modifier.weight(1f),
                            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = quantity,
                            onValueChange = { quantity = it },
                            label = { Text("الكمية") },
                            modifier = Modifier.weight(1f),
                            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number)
                        )
                        OutlinedTextField(
                            value = lowStockLimit,
                            onValueChange = { lowStockLimit = it },
                            label = { Text("حد الإنذار") },
                            modifier = Modifier.weight(1f),
                            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = productionDate,
                            onValueChange = { productionDate = it },
                            label = { Text("تاريخ الإنتاج (YYYY-MM-DD)") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = expirationDate,
                            onValueChange = { expirationDate = it },
                            label = { Text("تاريخ الانتهاء (YYYY-MM-DD)") },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    OutlinedTextField(
                        value = batchNumber,
                        onValueChange = { batchNumber = it },
                        label = { Text("رقم التشغيلة (Batch Number)") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("ملاحظات") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("إلغاء")
                    }

                    if (product != null && onDelete != null) {
                        Button(
                            onClick = { onDelete(product) },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = null)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("حذف")
                        }
                    }

                    Button(
                        onClick = {
                            if (tradeName.isEmpty() || salePrice.isEmpty()) return@Button
                            val selectedCompName = companies.find { it.id == selectedCompanyId }?.name ?: "غير محدد"
                            val newProduct = Product(
                                id = product?.id ?: 0,
                                tradeName = tradeName,
                                scientificName = scientificName,
                                manufacturerId = selectedCompanyId,
                                manufacturerName = selectedCompName,
                                category = category,
                                barcode = if (barcode.isEmpty()) (1000000000000..9999999999999).random().toString() else barcode,
                                purchasePrice = purchasePrice.toDoubleOrNull() ?: 0.0,
                                salePrice = salePrice.toDoubleOrNull() ?: 0.0,
                                quantity = quantity.toIntOrNull() ?: 0,
                                productionDate = productionDate,
                                expirationDate = expirationDate,
                                batchNumber = batchNumber,
                                notes = notes,
                                lowStockLimit = lowStockLimit.toIntOrNull() ?: 10
                            )
                            onSave(newProduct)
                        },
                        modifier = Modifier.weight(1.5f)
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("حفظ")
                    }
                }
            }
        }
    }

    if (showCameraScanner) {
        ProductBarcodeScannerSimDialog(
            onDismiss = { showCameraScanner = false },
            onBarcodeScanned = { scannedBarcode ->
                barcode = scannedBarcode
                showCameraScanner = false
            }
        )
    }
}

@Composable
fun CompanyFormDialog(
    company: Company? = null,
    onDismiss: () -> Unit,
    onSave: (Company) -> Unit,
    onDelete: ((Company) -> Unit)? = null
) {
    var name by remember { mutableStateOf(company?.name ?: "") }
    var phone by remember { mutableStateOf(company?.phone ?: "") }
    var email by remember { mutableStateOf(company?.email ?: "") }
    var address by remember { mutableStateOf(company?.address ?: "") }
    var notes by remember { mutableStateOf(company?.notes ?: "") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight(),
            shape = RoundedCornerShape(24.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = if (company == null) "إضافة شركة دواء ومورد" else "تعديل بيانات الشركة",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("اسم الشركة") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("رقم الهاتف") },
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Phone)
                )

                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("البريد الإلكتروني") },
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Email)
                )

                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("العنوان") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("ملاحظات المورد") },
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("إلغاء")
                    }

                    if (company != null && onDelete != null) {
                        Button(
                            onClick = { onDelete(company) },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("حذف")
                        }
                    }

                    Button(
                        onClick = {
                            if (name.isEmpty()) return@Button
                            val newCompany = Company(
                                id = company?.id ?: 0,
                                name = name,
                                phone = phone,
                                email = email,
                                address = address,
                                notes = notes
                            )
                            onSave(newCompany)
                        },
                        modifier = Modifier.weight(1.5f)
                    ) {
                        Text("حفظ")
                    }
                }
            }
        }
    }
}

@Composable
fun InvoiceDetailDialog(
    invoice: Invoice,
    viewModel: PharmacyViewModel,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var items by remember { mutableStateOf<List<InvoiceItem>>(emptyList()) }

    LaunchedEffect(invoice.id) {
        viewModel.getItemsForInvoice(invoice.id).collect {
            items = it
        }
    }

    val sdf = SimpleDateFormat("yyyy-MM-dd hh:mm a", Locale.getDefault())
    val dateString = sdf.format(Date(invoice.timestamp))

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.8f),
            shape = RoundedCornerShape(24.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        Icons.Default.LocalPharmacy,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(36.dp)
                    )
                    Text(
                        "صيدلية الشفاء والبركة",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text(
                        "هاتف: 0112345678 | القاهرة، مصر",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Divider(modifier = Modifier.padding(vertical = 8.dp))
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("فاتورة مبيعات: ${invoice.invoiceNumber}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("التاريخ: $dateString", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("البائع: ${invoice.soldBy}", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("الحالة: مدفوع", fontSize = 11.sp, color = Color(0xFF2E7D32))
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.background.copy(alpha = 0.5f))
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        .padding(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .padding(4.dp)
                        ) {
                            Text("الدواء", modifier = Modifier.weight(1.5f), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            Text("الكمية", modifier = Modifier.weight(0.7f), fontWeight = FontWeight.Bold, fontSize = 11.sp, textAlign = TextAlign.Center)
                            Text("السعر", modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 11.sp, textAlign = TextAlign.End)
                            Text("الإجمالي", modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 11.sp, textAlign = TextAlign.End)
                        }
                    }

                    items(items) { item ->
                        Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 2.dp)) {
                            Text(item.productName, modifier = Modifier.weight(1.5f), fontSize = 11.sp)
                            Text("${item.quantity}", modifier = Modifier.weight(0.7f), fontSize = 11.sp, textAlign = TextAlign.Center)
                            Text(String.format(Locale.US, "%.1f", item.salePrice), modifier = Modifier.weight(1f), fontSize = 11.sp, textAlign = TextAlign.End)
                            Text(String.format(Locale.US, "%.1f", item.total), modifier = Modifier.weight(1f), fontSize = 11.sp, textAlign = TextAlign.End)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("المجموع:", fontSize = 12.sp)
                            Text(invoice.subtotal.formatIqd(), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        if (invoice.discount > 0) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("الخصم الممنوح:", fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
                                Text("-${invoice.discount.formatIqd()}", fontSize = 12.sp, color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                            }
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("الضريبة:", fontSize = 12.sp)
                            Text(invoice.tax.formatIqd(), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Divider(modifier = Modifier.padding(vertical = 4.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("الإجمالي الكلي:", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            Text(invoice.total.formatIqd(), fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("إغلاق")
                    }

                    Button(
                        onClick = { viewModel.showToast("جاري التوصيل بالطابعة الحرارية المخصصة...") },
                        modifier = Modifier.weight(1.2f)
                    ) {
                        Icon(Icons.Default.Print, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("طباعة")
                    }

                    Button(
                        onClick = {
                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_SUBJECT, "فاتورة صيدلية")
                                putExtra(Intent.EXTRA_TEXT, "رقم الفاتورة: ${invoice.invoiceNumber}\nالإجمالي: ${invoice.total.formatIqd()}\nشكراً لزيارتكم!")
                            }
                            context.startActivity(Intent.createChooser(shareIntent, "مشاركة الفاتورة"))
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("مشاركة")
                    }
                }
            }
        }
    }
}

@Composable
fun CheckoutPOSDialog(
    viewModel: PharmacyViewModel,
    onDismiss: () -> Unit,
    onCheckoutSuccess: () -> Unit
) {
    var discountInput by remember { mutableStateOf(viewModel.discountPercent.toString()) }
    var cashPaidInput by remember { mutableStateOf("") }

    LaunchedEffect(discountInput) {
        viewModel.discountPercent = discountInput.toDoubleOrNull() ?: 0.0
    }
    LaunchedEffect(cashPaidInput) {
        viewModel.cashPaidAmount = cashPaidInput.toDoubleOrNull() ?: 0.0
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight(),
            shape = RoundedCornerShape(24.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    "تأكيد عملية الدفع والبيع",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("المجموع الفرعي:")
                    Text(viewModel.getCartSubtotal().formatIqd(), fontWeight = FontWeight.Bold)
                }

                OutlinedTextField(
                    value = discountInput,
                    onValueChange = { discountInput = it },
                    label = { Text("نسبة الخصم الممنوح (%)") },
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("ضريبة القيمة المضافة (15%):")
                    Text(viewModel.getCartTaxAmount().formatIqd(), fontWeight = FontWeight.Bold)
                }

                Divider()

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("الإجمالي الكلي المطلوب:", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        viewModel.getCartTotal().formatIqd(),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                OutlinedTextField(
                    value = cashPaidInput,
                    onValueChange = { cashPaidInput = it },
                    label = { Text("المبلغ المستلم نقداً") },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("مثال: 10000") },
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number)
                )

                if (viewModel.getCartChangeDue() > 0 && viewModel.cashPaidAmount >= viewModel.getCartTotal()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFFE8F5E9))
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("الباقي المرتجع للعميل:", fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32))
                        Text(viewModel.getCartChangeDue().formatIqd(), fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32))
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("إلغاء")
                    }

                    Button(
                        onClick = {
                            val ok = viewModel.checkoutCart()
                            if (ok) {
                                onCheckoutSuccess()
                            }
                        },
                        modifier = Modifier.weight(1.5f),
                        enabled = viewModel.cashPaidAmount >= viewModel.getCartTotal()
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("حفظ الفاتورة")
                    }
                }
            }
        }
    }
}

@Composable
fun ChangePasswordDialog(
    viewModel: PharmacyViewModel,
    onDismiss: () -> Unit
) {
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight(),
            shape = RoundedCornerShape(24.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    "تغيير كلمة المرور الخاصة بك",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("كلمة المرور الجديدة") },
                    modifier = Modifier.fillMaxWidth(),
                    visualTransformation = PasswordVisualTransformation()
                )

                OutlinedTextField(
                    value = confirmPassword,
                    onValueChange = { confirmPassword = it },
                    label = { Text("تأكيد كلمة المرور الجديدة") },
                    modifier = Modifier.fillMaxWidth(),
                    visualTransformation = PasswordVisualTransformation()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("إلغاء")
                    }

                    Button(
                        onClick = {
                            if (password.isEmpty()) return@Button
                            if (password != confirmPassword) {
                                viewModel.showToast("كلمات المرور غير متطابقة!")
                                return@Button
                            }
                            viewModel.changePassword(password)
                            onDismiss()
                        },
                        modifier = Modifier.weight(1.5f)
                    ) {
                        Text("تغيير الآن")
                    }
                }
            }
        }
    }
}

@Composable
fun BarcodeScannerSimDialog(
    products: List<Product>,
    onDismiss: () -> Unit,
    onBarcodeScanned: (String) -> Unit
) {
    var manualBarcode by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.75f),
            shape = RoundedCornerShape(24.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 10.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                Text(
                    "محاكي قارئ الباركود الذكي بالكاميرا",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(bottom = 6.dp)
                )
                
                Text(
                    "هنا يمكنك محاكاة تمرير عبوة الدواء أمام الكاميرا. اختر الدواء لمحاكاة مسح ملصق الباركود الخاص به فوراً أو أدخل الباركود يدوياً:",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        .background(MaterialTheme.colorScheme.background.copy(alpha = 0.5f))
                        .padding(4.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(products) { prod ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onBarcodeScanned(prod.barcode) },
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(prod.tradeName, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Text("باركود: ${prod.barcode}", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(MaterialTheme.colorScheme.secondaryContainer)
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text("محاكاة مسح", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSecondaryContainer, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = manualBarcode,
                    onValueChange = { manualBarcode = it },
                    label = { Text("إدخال الباركود يدوياً") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number)
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("إلغاء")
                    }

                    Button(
                        onClick = {
                            if (manualBarcode.isNotEmpty()) {
                                onBarcodeScanned(manualBarcode)
                            }
                        },
                        modifier = Modifier.weight(1.5f),
                        enabled = manualBarcode.isNotEmpty()
                    ) {
                        Text("مسح الباركود")
                    }
                }
            }
        }
    }
}

@Composable
fun ProductBarcodeScannerSimDialog(
    onDismiss: () -> Unit,
    onBarcodeScanned: (String) -> Unit
) {
    var manualBarcode by remember { mutableStateOf("") }
    
    val sampleProducts = listOf(
        Pair("بنادول إكسترا (Panadol Extra)", "6221124010211"),
        Pair("أسبيرين 81 (Aspirin 81)", "4000540001423"),
        Pair("أموكسيسيلين 500 (Amoxicillin)", "6251007011402"),
        Pair("أوجمنتين 1 جم (Augmentin)", "5011116012351"),
        Pair("بروفين 400 (Brufen 400)", "5000158061453"),
        Pair("فيتامين سي فوار (Vitamin C)", "7612076352924")
    )

    val infiniteTransition = rememberInfiniteTransition(label = "ScannerAnim")
    val translationY by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 200f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "ScanningLine"
    )

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f),
            shape = RoundedCornerShape(24.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 12.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                Text(
                    "قارئ ومسجل الباركود بالكاميرا",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(bottom = 4.dp)
                )
                Text(
                    "وجه كاميرا الهاتف نحو الباركود لقراءته أو اختر دواءً شائعاً لمحاكاة مسح ملصقه وتسجيله فوراً:",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                // --- Viewfinder Box with red scan animation ---
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color.Black)
                        .border(2.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(16.dp))
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    // Futuristic glowing scanner box corners
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val cornerSize = 24.dp.toPx()
                        val strokeWidth = 4.dp.toPx()
                        val color = Color(0xFF00E676) // Bright green
                        
                        // Top Left
                        drawRect(color, Offset(0f, 0f), Size(cornerSize, strokeWidth))
                        drawRect(color, Offset(0f, 0f), Size(strokeWidth, cornerSize))
                        
                        // Top Right
                        drawRect(color, Offset(size.width - cornerSize, 0f), Size(cornerSize, strokeWidth))
                        drawRect(color, Offset(size.width - strokeWidth, 0f), Size(strokeWidth, cornerSize))
                        
                        // Bottom Left
                        drawRect(color, Offset(0f, size.height - strokeWidth), Size(cornerSize, strokeWidth))
                        drawRect(color, Offset(0f, size.height - cornerSize), Size(strokeWidth, cornerSize))
                        
                        // Bottom Right
                        drawRect(color, Offset(size.width - cornerSize, size.height - strokeWidth), Size(cornerSize, strokeWidth))
                        drawRect(color, Offset(size.width - strokeWidth, size.height - cornerSize), Size(strokeWidth, cornerSize))
                    }

                    // Simulated Camera viewfinder grid/guides
                    Icon(
                        Icons.Default.QrCodeScanner,
                        contentDescription = null,
                        tint = Color.White.copy(alpha = 0.15f),
                        modifier = Modifier.size(100.dp)
                    )

                    // Animated Scanning Laser Line
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.9f)
                            .height(2.dp)
                            .offset(y = (translationY - 100).dp)
                            .background(
                                Brush.horizontalGradient(
                                    colors = listOf(Color.Transparent, Color.Red, Color.Red, Color.Transparent)
                                )
                            )
                            .border(1.dp, Color.Red.copy(alpha = 0.5f))
                    )

                    // Text status indicator
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.Black.copy(alpha = 0.6f))
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF00E676))
                            )
                            Text(
                                "جاري المسح الضوئي بالكاميرا...",
                                color = Color.White,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    "أدوية شائعة للتمثيل السريع والمسح:",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 6.dp)
                )

                // List of sample drugs to click & register
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(sampleProducts) { (name, bar) ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onBarcodeScanned(bar) },
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Text(name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text("الباركود: $bar", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color(0xFFE8F5E9))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text("محاكاة مسح", fontSize = 10.sp, color = Color(0xFF2E7D32), fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Manual scanned code
                OutlinedTextField(
                    value = manualBarcode,
                    onValueChange = { manualBarcode = it },
                    label = { Text("أو اكتب الباركود المراد قراءته يدوياً") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number)
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("إلغاء")
                    }

                    Button(
                        onClick = {
                            if (manualBarcode.isNotEmpty()) {
                                onBarcodeScanned(manualBarcode)
                            }
                        },
                        modifier = Modifier.weight(1.5f),
                        enabled = manualBarcode.isNotEmpty(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("تأكيد القراءة والمسح")
                    }
                }
            }
        }
    }
}
