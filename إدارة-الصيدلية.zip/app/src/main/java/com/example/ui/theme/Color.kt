package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Clinical Pharmacy Colors
val PharmacyPrimary = Color(0xFF00796B)      // Deep Teal
val PharmacySecondary = Color(0xFF00BFA5)    // Medical Mint
val PharmacyTertiary = Color(0xFF0288D1)     // Clinical Blue
val PharmacyBackground = Color(0xFFF4F6F6)   // Soft Greyish-Blue White
val PharmacySurface = Color(0xFFFFFFFF)      // Pure White
val PharmacyOnPrimary = Color(0xFFFFFFFF)
val PharmacyOnSecondary = Color(0xFF004D40)
val PharmacyOnError = Color(0xFFFFFFFF)
val PharmacyError = Color(0xFFD32F2F)

// Dark Theme Clinical Pharmacy Colors
val PharmacyPrimaryDark = Color(0xFF4DB6AC)  // Soft Teal
val PharmacySecondaryDark = Color(0xFF64FFDA) // Vivid Mint
val PharmacyTertiaryDark = Color(0xFF4FC3F7)  // Soft Blue
val PharmacyBackgroundDark = Color(0xFF12181B) // Slate Dark
val PharmacySurfaceDark = Color(0xFF1E272C)    // Dark Card Background
val PharmacyOnPrimaryDark = Color(0xFF003730)
val PharmacyOnSecondaryDark = Color(0xFF004D40)
