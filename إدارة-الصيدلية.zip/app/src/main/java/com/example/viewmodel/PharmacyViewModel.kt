package com.example.viewmodel

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

data class CartItem(
    val product: Product,
    val quantity: Int
)

class PharmacyViewModel(application: Application) : AndroidViewModel(application) {

    private val db = PharmacyDatabase.getDatabase(application)
    val repository = PharmacyRepository(db)

    // Current logged-in user
    var currentUser by mutableStateOf<User?>(null)
        private set

    // Selected tabs/screens
    var currentScreen by mutableStateOf("dashboard")

    // POS Cart State
    var cart = mutableStateOf<List<CartItem>>(emptyList())
        private set

    var discountPercent by mutableStateOf(0.0)
    var taxPercent by mutableStateOf(15.0) // 15% VAT standard in some regions
    var cashPaidAmount by mutableStateOf(0.0)

    // Search queries
    var posSearchQuery by mutableStateOf("")
    var productSearchQuery by mutableStateOf("")
    var companySearchQuery by mutableStateOf("")

    // Database states as StateFlows
    val allProductsState: StateFlow<List<Product>> = repository.allProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allCompaniesState: StateFlow<List<Company>> = repository.allCompanies
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allInvoicesState: StateFlow<List<Invoice>> = repository.allInvoices
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val lowStockState: StateFlow<List<Product>> = repository.lowStockProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // UI feedback messages
    var toastMessage by mutableStateOf<String?>(null)

    // --- Bluetooth Printer State ---
    var selectedBluetoothPrinter by mutableStateOf<String?>(null)
    var isBluetoothConnected by mutableStateOf(false)
    val bluetoothDevices = listOf(
        "XP-58 Thermal Printer (58mm)",
        "MPT-II Mobile Bluetooth Printer (58mm)",
        "Bixolon SPP-R200 (80mm)",
        "صيدلية - طابعة فواتير ذكية"
    )

    fun connectToBluetoothPrinter(printerName: String) {
        selectedBluetoothPrinter = printerName
        isBluetoothConnected = true
        showToast("تم الاتصال بنجاح بالطابعة: $printerName")
    }

    fun disconnectPrinter() {
        val name = selectedBluetoothPrinter
        selectedBluetoothPrinter = null
        isBluetoothConnected = false
        if (name != null) {
            showToast("تم قطع الاتصال بالطابعة: $name")
        }
    }

    init {
        viewModelScope.launch {
            // Pre-populate DB with sample data if first run
            repository.prepopulateIfNeeded()
            // Log in as default admin to let user explore immediately
            val adminUser = repository.getUserByUsername("admin")
            currentUser = adminUser
        }
    }

    // --- Authentication ---
    fun login(username: String, passwordCharSeq: String): Boolean {
        var success = false
        viewModelScope.launch {
            val user = repository.getUserByUsername(username)
            if (user != null && user.passwordHash == passwordCharSeq) {
                currentUser = user
                success = true
                showToast("مرحباً بك، ${user.fullName}")
            } else {
                showToast("خطأ في اسم المستخدم أو كلمة المرور")
            }
        }
        return success
    }

    fun logout() {
        currentUser = null
        showToast("تم تسجيل الخروج بنجاح")
    }

    fun changePassword(newPassword: String) {
        val user = currentUser ?: return
        viewModelScope.launch {
            repository.updatePassword(user.id, newPassword)
            currentUser = user.copy(passwordHash = newPassword)
            showToast("تم تغيير كلمة المرور بنجاح")
        }
    }

    // --- POS Actions ---
    fun addToCart(product: Product) {
        if (product.quantity <= 0) {
            showToast("عذراً، هذا المنتج منتهي من المخزن!")
            return
        }
        val currentCart = cart.value.toMutableList()
        val index = currentCart.indexOfFirst { it.product.id == product.id }
        if (index != -1) {
            val existingItem = currentCart[index]
            if (existingItem.quantity + 1 > product.quantity) {
                showToast("لا يمكن تجاوز الكمية المتاحة في المخزن (${product.quantity})")
                return
            }
            currentCart[index] = existingItem.copy(quantity = existingItem.quantity + 1)
        } else {
            currentCart.add(CartItem(product, 1))
        }
        cart.value = currentCart
    }

    fun updateCartQuantity(product: Product, quantity: Int) {
        if (quantity <= 0) {
            removeFromCart(product)
            return
        }
        if (quantity > product.quantity) {
            showToast("لا يمكن تجاوز الكمية المتاحة في المخزن (${product.quantity})")
            return
        }
        val currentCart = cart.value.toMutableList()
        val index = currentCart.indexOfFirst { it.product.id == product.id }
        if (index != -1) {
            currentCart[index] = currentCart[index].copy(quantity = quantity)
            cart.value = currentCart
        }
    }

    fun removeFromCart(product: Product) {
        val currentCart = cart.value.toMutableList()
        currentCart.removeAll { it.product.id == product.id }
        cart.value = currentCart
    }

    fun clearCart() {
        cart.value = emptyList()
        discountPercent = 0.0
        cashPaidAmount = 0.0
    }

    fun getCartSubtotal(): Double {
        return cart.value.sumOf { it.product.salePrice * it.quantity }
    }

    fun getCartDiscountAmount(): Double {
        return getCartSubtotal() * (discountPercent / 100.0)
    }

    fun getCartTaxAmount(): Double {
        val taxableAmount = getCartSubtotal() - getCartDiscountAmount()
        return taxableAmount * (taxPercent / 100.0)
    }

    fun getCartTotal(): Double {
        return getCartSubtotal() - getCartDiscountAmount() + getCartTaxAmount()
    }

    fun getCartChangeDue(): Double {
        return (cashPaidAmount - getCartTotal()).coerceAtLeast(0.0)
    }

    fun checkoutCart(): Boolean {
        if (cart.value.isEmpty()) {
            showToast("سلة المشتريات فارغة!")
            return false
        }
        if (cashPaidAmount < getCartTotal()) {
            showToast("المبلغ المدفوع غير كافٍ!")
            return false
        }

        val invoiceNum = "INV-${System.currentTimeMillis() % 1000000}"
        val userFullName = currentUser?.fullName ?: "غير معروف"

        val invoice = Invoice(
            invoiceNumber = invoiceNum,
            subtotal = getCartSubtotal(),
            discount = getCartDiscountAmount(),
            tax = getCartTaxAmount(),
            total = getCartTotal(),
            cashPaid = cashPaidAmount,
            changeDue = getCartChangeDue(),
            soldBy = userFullName
        )

        val invoiceItems = cart.value.map {
            InvoiceItem(
                invoiceId = 0, // will be overwritten in transaction
                productId = it.product.id,
                productName = it.product.tradeName,
                quantity = it.quantity,
                salePrice = it.product.salePrice,
                total = it.product.salePrice * it.quantity
            )
        }

        viewModelScope.launch {
            repository.createInvoice(invoice, invoiceItems)
            clearCart()
            showToast("تم حفظ الفاتورة بنجاح: $invoiceNum")
        }
        return true
    }

    fun scanBarcodeAndAdd(barcode: String) {
        viewModelScope.launch {
            val product = repository.getProductByBarcode(barcode)
            if (product != null) {
                addToCart(product)
                showToast("تم إضافة: ${product.tradeName}")
            } else {
                showToast("المنتج ذو الباركود ($barcode) غير موجود بالمخزن!")
            }
        }
    }

    fun getItemsForInvoice(invoiceId: Int): Flow<List<InvoiceItem>> {
        return repository.getItemsForInvoice(invoiceId)
    }

    // --- Product Actions ---
    fun addProduct(product: Product) {
        viewModelScope.launch {
            repository.insertProduct(product)
            showToast("تم إضافة المنتج بنجاح")
        }
    }

    fun updateProduct(product: Product) {
        viewModelScope.launch {
            repository.updateProduct(product)
            showToast("تم تعديل المنتج بنجاح")
        }
    }

    fun deleteProduct(product: Product) {
        viewModelScope.launch {
            repository.deleteProduct(product)
            showToast("تم حذف المنتج")
        }
    }

    // --- Company Actions ---
    fun addCompany(company: Company) {
        viewModelScope.launch {
            repository.insertCompany(company)
            showToast("تم إضافة الشركة بنجاح")
        }
    }

    fun updateCompany(company: Company) {
        viewModelScope.launch {
            repository.updateCompany(company)
            showToast("تم تعديل الشركة بنجاح")
        }
    }

    fun deleteCompany(company: Company) {
        viewModelScope.launch {
            repository.deleteCompany(company)
            showToast("تم حذف الشركة")
        }
    }

    // --- Helpers ---
    fun showToast(msg: String) {
        toastMessage = msg
    }

    fun clearToast() {
        toastMessage = null
    }

    // Helper for expirations
    fun isExpired(dateString: String): Boolean {
        return try {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val expiryDate = sdf.parse(dateString) ?: return false
            expiryDate.before(Date())
        } catch (e: Exception) {
            false
        }
    }

    fun isNearExpiry(dateString: String): Boolean {
        return try {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val expiryDate = sdf.parse(dateString) ?: return false
            val cal = Calendar.getInstance()
            cal.add(Calendar.DAY_OF_YEAR, 60) // within 60 days
            expiryDate.after(Date()) && expiryDate.before(cal.time)
        } catch (e: Exception) {
            false
        }
    }
}
