import { Debtor, InstallmentRecord, Supplier, DebtorTransaction } from '../types';

export interface TextReportExportOptions {
  branchName?: string;
  userName?: string;
  currencySymbol?: string;
}

/**
 * Shares a .txt file directly using Native Web Share API without emojis
 */
export const shareTextFile = async (
  content: string,
  fileName: string,
  title: string
): Promise<{ success: boolean; method: 'native_file' | 'native_text' | 'download_fallback' }> => {
  const cleanFileName = fileName.endsWith('.txt') ? fileName : `${fileName}.txt`;
  const blob = new Blob(['\uFEFF' + content], { type: 'text/plain;charset=utf-8;' });

  // 1. Try Native Web Share with actual file
  if (typeof navigator !== 'undefined' && navigator.share) {
    try {
      const file = new File([blob], cleanFileName, { type: 'text/plain' });
      if (navigator.canShare && navigator.canShare({ files: [file] })) {
        await navigator.share({
          files: [file],
          title,
          text: title,
        });
        return { success: true, method: 'native_file' };
      }
    } catch (err: any) {
      if (err?.name === 'AbortError') {
        return { success: true, method: 'native_file' };
      }
      console.warn('Native file share failed, trying text share fallback:', err);
    }

    // 2. Try Native Web Share with text
    try {
      await navigator.share({
        title,
        text: content,
      });
      return { success: true, method: 'native_text' };
    } catch (err: any) {
      if (err?.name === 'AbortError') {
        return { success: true, method: 'native_text' };
      }
      console.warn('Native text share failed, falling back to download:', err);
    }
  }

  // 3. Fallback: Direct Download only if share is unsupported
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = cleanFileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  return { success: true, method: 'download_fallback' };
};

/**
 * Shares the statement directly to the person's phone via WhatsApp if a phone number exists,
 * or falls back to native share / text file download.
 */
export const shareReportToPerson = async ({
  phone,
  text,
  fileName,
  title,
}: {
  phone?: string | null;
  text: string;
  fileName: string;
  title: string;
}): Promise<{ success: boolean; method: 'whatsapp_direct' | 'native_file' | 'native_text' | 'download_fallback' }> => {
  if (phone && phone.trim()) {
    const cleanPhone = phone.replace(/[^0-9]/g, '');
    let formattedPhone = cleanPhone;
    if (formattedPhone.startsWith('07')) {
      formattedPhone = '964' + formattedPhone.substring(1);
    } else if (formattedPhone.startsWith('7') && formattedPhone.length === 10) {
      formattedPhone = '964' + formattedPhone;
    } else if (formattedPhone.startsWith('00')) {
      formattedPhone = formattedPhone.substring(2);
    }
    if (formattedPhone.length >= 8) {
      const url = `https://api.whatsapp.com/send?phone=${formattedPhone}&text=${encodeURIComponent(text)}`;
      window.open(url, '_blank');
      return { success: true, method: 'whatsapp_direct' };
    }
  }

  return await shareTextFile(text, fileName, title);
};

// ----------------------------------------------------
// 1. GENERATE FULL DEBTORS REPORT TEXT (Clean - No Emojis)
// ----------------------------------------------------
export const generateDebtorsTextReport = (
  debtors: Debtor[],
  historyMap: Record<string, DebtorTransaction[]> = {},
  options: TextReportExportOptions = {}
): string => {
  const { branchName = 'الفرع الرئيسي', userName = 'المسؤول', currencySymbol = 'د.ع' } = options;
  const realDebtors = debtors.filter((d) => !d.isDemo && d.type !== 'creditor');

  const totalDebt = realDebtors.reduce((sum, d) => sum + (Number(d.amount) || 0), 0);
  const now = new Date();
  const dateStr = `${now.getFullYear()}/${String(now.getMonth() + 1).padStart(2, '0')}/${String(now.getDate()).padStart(2, '0')}`;

  let text = `تقرير ديون العملاء\n\n`;
  text += `الحساب: ${branchName}\n`;
  text += `المستخدم: ${userName}\n`;
  text += `التاريخ: ${dateStr}\n`;
  text += `عدد المدينين: ${realDebtors.length}\n`;
  text += `إجمالي الديون: ${totalDebt.toLocaleString('en-US')} ${currencySymbol}\n`;
  text += `━━━━━━━━━━━━━━\n\n`;

  if (realDebtors.length === 0) {
    text += `لا توجد سجلات مدينين مسجلة.\n\n`;
  } else {
    realDebtors.forEach((d) => {
      const rawHist = historyMap[String(d.id)] || d.history || [];
      const statusLabel = Number(d.amount) === 0 ? 'مسدد بالكامل' : 'متبقي عليه دين';
      const openDate = d.createdAt ? d.createdAt.split('T')[0].replace(/-/g, '/') : '—';
      const lastDate = d.lastDebtDate ? d.lastDebtDate.split('T')[0].replace(/-/g, '/') : openDate;

      text += `العميل: ${d.name}\n`;
      text += `الهاتف: ${d.phone || 'غير مسجل'}\n`;
      text += `الرصيد المطلوب: ${Number(d.amount).toLocaleString('en-US')} ${currencySymbol}\n`;
      text += `الحالة: ${statusLabel}\n`;
      text += `فتح الحساب: ${openDate}\n`;
      text += `آخر حركة: ${lastDate}\n\n`;

      text += `الحركات:\n`;
      if (rawHist.length > 0) {
        rawHist.forEach((tx) => {
          const isPay = tx.type === 'pay';
          const typeStr = isPay ? 'تسديد دفعة: -' : 'إضافة دين: +';
          const noteStr = tx.notes || tx.description ? ` (${tx.notes || tx.description})` : '';
          text += `• ${typeStr}${Number(tx.amount).toLocaleString('en-US')} ${currencySymbol}${noteStr}\n`;
        });
      } else {
        text += `• لا توجد حركات مسجلة\n`;
      }

      text += `\n━━━━━━━━━━━━━━\n\n`;
    });
  }

  text += `الرصيد الحالي: ${totalDebt.toLocaleString('en-US')} ${currencySymbol}\n\n`;
  text += `نظام دفتر الديون والأقساط والموردين`;

  return text;
};

// ----------------------------------------------------
// 2. GENERATE FULL CREDITORS REPORT TEXT (Clean - No Emojis)
// ----------------------------------------------------
export const generateCreditorsTextReport = (
  debtors: Debtor[],
  historyMap: Record<string, DebtorTransaction[]> = {},
  options: TextReportExportOptions = {}
): string => {
  const { branchName = 'الفرع الرئيسي', userName = 'المسؤول', currencySymbol = 'د.ع' } = options;
  const creditors = debtors.filter((d) => !d.isDemo && d.type === 'creditor');

  const totalOwed = creditors.reduce((sum, c) => sum + (Number(c.amount) || 0), 0);
  const now = new Date();
  const dateStr = `${now.getFullYear()}/${String(now.getMonth() + 1).padStart(2, '0')}/${String(now.getDate()).padStart(2, '0')}`;

  let text = `تقرير الدائنين (ديون عليّ)\n\n`;
  text += `الحساب: ${branchName}\n`;
  text += `المستخدم: ${userName}\n`;
  text += `التاريخ: ${dateStr}\n`;
  text += `عدد الدائنين: ${creditors.length}\n`;
  text += `إجمالي المبالغ المستحقة: ${totalOwed.toLocaleString('en-US')} ${currencySymbol}\n`;
  text += `━━━━━━━━━━━━━━\n\n`;

  if (creditors.length === 0) {
    text += `لا توجد ديون مسجلة عليك للآخرين.\n\n`;
  } else {
    creditors.forEach((c) => {
      const rawHist = historyMap[String(c.id)] || c.history || [];
      const statusLabel = Number(c.amount) === 0 ? 'تم السداد بالكامل' : 'مستحق السداد';
      const openDate = c.createdAt ? c.createdAt.split('T')[0].replace(/-/g, '/') : '—';
      const lastDate = c.lastDebtDate ? c.lastDebtDate.split('T')[0].replace(/-/g, '/') : openDate;

      text += `الدائن: ${c.name}\n`;
      text += `الهاتف: ${c.phone || 'غير مسجل'}\n`;
      text += `المبلغ المطلوب مني: ${Number(c.amount).toLocaleString('en-US')} ${currencySymbol}\n`;
      text += `الحالة: ${statusLabel}\n`;
      text += `فتح الحساب: ${openDate}\n`;
      text += `آخر حركة: ${lastDate}\n\n`;

      text += `الحركات:\n`;
      if (rawHist.length > 0) {
        rawHist.forEach((tx) => {
          const isPay = tx.type === 'pay';
          const typeStr = isPay ? 'سداد دفعة له: -' : 'استدانة مبلغ: +';
          const noteStr = tx.notes || tx.description ? ` (${tx.notes || tx.description})` : '';
          text += `• ${typeStr}${Number(tx.amount).toLocaleString('en-US')} ${currencySymbol}${noteStr}\n`;
        });
      } else {
        text += `• لا توجد حركات مسجلة\n`;
      }

      text += `\n━━━━━━━━━━━━━━\n\n`;
    });
  }

  text += `المتبقي عليّ حالياً: ${totalOwed.toLocaleString('en-US')} ${currencySymbol}\n\n`;
  text += `نظام دفتر الديون والأقساط والموردين`;

  return text;
};

// ----------------------------------------------------
// 3. GENERATE FULL INSTALLMENTS REPORT TEXT (Clean - No Emojis)
// ----------------------------------------------------
export const generateInstallmentsTextReport = (
  installments: InstallmentRecord[],
  options: TextReportExportOptions = {}
): string => {
  const { branchName = 'الفرع الرئيسي', userName = 'المسؤول', currencySymbol = 'د.ع' } = options;

  const totalRemaining = installments.reduce((sum, i) => sum + (Number(i.remainingAmount) || 0), 0);
  const now = new Date();
  const dateStr = `${now.getFullYear()}/${String(now.getMonth() + 1).padStart(2, '0')}/${String(now.getDate()).padStart(2, '0')}`;

  let text = `تقرير عقود الأقساط\n\n`;
  text += `الحساب: ${branchName}\n`;
  text += `المستخدم: ${userName}\n`;
  text += `التاريخ: ${dateStr}\n`;
  text += `عدد العقود: ${installments.length}\n`;
  text += `إجمالي المتبقي للتحصيل: ${totalRemaining.toLocaleString('en-US')} ${currencySymbol}\n`;
  text += `━━━━━━━━━━━━━━\n\n`;

  if (installments.length === 0) {
    text += `لا توجد عقود أقساط مسجلة.\n\n`;
  } else {
    installments.forEach((inst) => {
      const isCompleted = (Number(inst.remainingAmount) || 0) <= 0 || inst.status === 'completed';
      const statusLabel = isCompleted ? 'مكتمل ومسدد بالكامل' : 'مستمر (نشط)';
      const payments = Array.isArray(inst.payments) ? inst.payments : [];
      const regDate = inst.registrationDate ? inst.registrationDate.replace(/-/g, '/') : '—';
      const nextDue = inst.nextDueDate ? inst.nextDueDate.replace(/-/g, '/') : '—';

      text += `العميل: ${inst.name}\n`;
      text += `الهاتف: ${inst.phone || 'غير مسجل'}\n`;
      text += `السلعة: ${inst.item || 'غير محدد'}\n`;
      text += `قيمة العقد الكلية: ${Number(inst.totalAmount).toLocaleString('en-US')} ${currencySymbol}\n`;
      text += `المقدم المدفوع: ${Number(inst.downPayment || 0).toLocaleString('en-US')} ${currencySymbol}\n`;
      text += `المتبقي المطلوب: ${Number(inst.remainingAmount).toLocaleString('en-US')} ${currencySymbol}\n`;
      if (inst.monthlyInstallmentAmount) {
        text += `القسط الشهري: ${Number(inst.monthlyInstallmentAmount).toLocaleString('en-US')} ${currencySymbol}\n`;
      }
      text += `تاريخ العقد: ${regDate}\n`;
      text += `القسط القادم: ${nextDue}\n`;
      text += `الحالة: ${statusLabel}\n\n`;

      text += `الدفعات المسددة:\n`;
      if (payments.length > 0) {
        payments.forEach((p) => {
          const pDate = p.date ? p.date.split('T')[0].replace(/-/g, '/') : '';
          const pNote = p.notes ? ` - ${p.notes}` : '';
          text += `• دفعة قسط: ${Number(p.amount).toLocaleString('en-US')} ${currencySymbol} (${pDate}${pNote})\n`;
        });
      } else {
        text += `• لم تسدد دفعات بعد (تم دفع المقدم فقط)\n`;
      }

      text += `\n━━━━━━━━━━━━━━\n\n`;
    });
  }

  text += `المتبقي النهائي: ${totalRemaining.toLocaleString('en-US')} ${currencySymbol}\n\n`;
  text += `نظام دفتر الديون والأقساط والموردين`;

  return text;
};

// ----------------------------------------------------
// 4. GENERATE FULL SUPPLIERS REPORT TEXT (Clean - No Emojis)
// ----------------------------------------------------
export const generateSuppliersTextReport = (
  suppliers: Supplier[],
  options: TextReportExportOptions = {}
): string => {
  const { branchName = 'الفرع الرئيسي', userName = 'المسؤول', currencySymbol = 'د.ع' } = options;
  const realSuppliers = suppliers.filter((s) => !s.isDemo);

  const totalDebt = realSuppliers.reduce(
    (sum, s) => sum + (Number(s.amount) || Number(s.totalDebt) || 0),
    0
  );

  const now = new Date();
  const dateStr = `${now.getFullYear()}/${String(now.getMonth() + 1).padStart(2, '0')}/${String(now.getDate()).padStart(2, '0')}`;

  let text = `تقرير حسابات الموردين\n\n`;
  text += `الحساب: ${branchName}\n`;
  text += `المستخدم: ${userName}\n`;
  text += `التاريخ: ${dateStr}\n`;
  text += `عدد الموردين: ${realSuppliers.length}\n`;
  text += `إجمالي المتبقي للموردين: ${totalDebt.toLocaleString('en-US')} ${currencySymbol}\n`;
  text += `━━━━━━━━━━━━━━\n\n`;

  if (realSuppliers.length === 0) {
    text += `لا توجد حسابات موردين مسجلة.\n\n`;
  } else {
    realSuppliers.forEach((s) => {
      const curDebt = Number(s.amount) || Number(s.totalDebt) || 0;
      const isCleared = curDebt === 0;
      const statusLabel = isCleared ? 'حساب خالص ومسدد' : 'نشط (يوجد رصيد)';
      const history = Array.isArray(s.history) ? s.history : [];
      const lastDate = s.lastTransactionDate ? s.lastTransactionDate.split('T')[0].replace(/-/g, '/') : '—';

      text += `المورد: ${s.name}${s.companyName ? ` (${s.companyName})` : ''}\n`;
      text += `الهاتف: ${s.phone || 'غير مسجل'}\n`;
      if (s.itemType) {
        text += `نوع البضاعة: ${s.itemType}\n`;
      }
      text += `المتبقي له في ذمتنا: ${curDebt.toLocaleString('en-US')} ${currencySymbol}\n`;
      text += `إجمالي المسدد له: ${Number(s.totalPaid || 0).toLocaleString('en-US')} ${currencySymbol}\n`;
      text += `الحالة: ${statusLabel}\n`;
      text += `آخر حركة: ${lastDate}\n\n`;

      text += `الفواتير والدفعات:\n`;
      if (history.length > 0) {
        history.forEach((tx) => {
          const isPay = tx.type === 'pay_supplier' || tx.type === 'pay';
          const typeStr = isPay ? 'سداد دفعة: -' : 'فاتورة توريد: +';
          const noteStr = tx.notes || tx.description ? ` (${tx.notes || tx.description})` : '';
          text += `• ${typeStr}${Number(tx.amount).toLocaleString('en-US')} ${currencySymbol}${noteStr}\n`;
        });
      } else {
        text += `• لا توجد حركات تفصيلية مسجلة\n`;
      }

      text += `\n━━━━━━━━━━━━━━\n\n`;
    });
  }

  text += `الرصيد الحالي للموردين: ${totalDebt.toLocaleString('en-US')} ${currencySymbol}\n\n`;
  text += `نظام دفتر الديون والأقساط والموردين`;

  return text;
};

// ----------------------------------------------------
// 5. GENERATE SINGLE DEBTOR / CREDITOR TEXT (Clean - No Emojis)
// ----------------------------------------------------
export const generateSingleDebtorTextReport = (
  debtor: Debtor,
  history: DebtorTransaction[] = [],
  options: TextReportExportOptions = {}
): string => {
  const { branchName = 'الفرع الرئيسي', userName = 'المسؤول', currencySymbol = 'د.ع' } = options;
  const isCreditor = debtor.type === 'creditor';

  const title = isCreditor ? 'كشف حساب دائن (ديون عليّ)' : 'كشف حساب عميل (ديون لي)';
  const partyLabel = isCreditor ? 'الدائن' : 'العميل';
  const balanceLabel = isCreditor ? 'المبلغ المطلوب مني' : 'الرصيد المطلوب';
  const statusLabel = Number(debtor.amount) === 0 ? (isCreditor ? 'تم السداد بالكامل' : 'مسدد بالكامل') : (isCreditor ? 'مستحق السداد' : 'متبقي عليه دين');
  const openDate = debtor.createdAt ? debtor.createdAt.split('T')[0].replace(/-/g, '/') : '—';
  const lastDate = debtor.lastDebtDate ? debtor.lastDebtDate.split('T')[0].replace(/-/g, '/') : openDate;

  const now = new Date();
  const dateStr = `${now.getFullYear()}/${String(now.getMonth() + 1).padStart(2, '0')}/${String(now.getDate()).padStart(2, '0')}`;

  let text = `${title}\n\n`;
  text += `الحساب: ${branchName}\n`;
  text += `المستخدم: ${userName}\n`;
  text += `التاريخ: ${dateStr}\n\n`;
  text += `━━━━━━━━━━━━━━\n\n`;

  text += `${partyLabel}: ${debtor.name}\n`;
  text += `الهاتف: ${debtor.phone || 'غير مسجل'}\n`;
  text += `${balanceLabel}: ${Number(debtor.amount).toLocaleString('en-US')} ${currencySymbol}\n`;
  text += `الحالة: ${statusLabel}\n`;
  text += `فتح الحساب: ${openDate}\n`;
  text += `آخر حركة: ${lastDate}\n\n`;

  text += `الحركات:\n`;
  const rawHist = history.length > 0 ? history : (debtor.history || []);
  if (rawHist.length > 0) {
    rawHist.forEach((tx) => {
      const isPay = tx.type === 'pay';
      let typeStr = '';
      if (isCreditor) {
        typeStr = isPay ? 'سداد دفعة له: -' : 'استدانة مبلغ: +';
      } else {
        typeStr = isPay ? 'تسديد دفعة: -' : 'إضافة دين: +';
      }
      const noteStr = tx.notes || tx.description ? ` (${tx.notes || tx.description})` : '';
      text += `• ${typeStr}${Number(tx.amount).toLocaleString('en-US')} ${currencySymbol}${noteStr}\n`;
    });
  } else {
    text += `• لا توجد حركات تفصيلية مسجلة\n`;
  }

  text += `\n━━━━━━━━━━━━━━\n\n`;
  text += `الرصيد الحالي: ${Number(debtor.amount).toLocaleString('en-US')} ${currencySymbol}\n\n`;
  text += `نظام دفتر الديون والأقساط والموردين`;

  return text;
};

// ----------------------------------------------------
// 6. GENERATE SINGLE INSTALLMENT TEXT (Clean - No Emojis)
// ----------------------------------------------------
export const generateSingleInstallmentTextReport = (
  installment: InstallmentRecord,
  options: TextReportExportOptions = {}
): string => {
  const { branchName = 'الفرع الرئيسي', userName = 'المسؤول', currencySymbol = 'د.ع' } = options;
  const isCompleted = (Number(installment.remainingAmount) || 0) <= 0 || installment.status === 'completed';
  const statusLabel = isCompleted ? 'مكتمل ومسدد بالكامل' : 'مستمر (نشط)';
  const payments = Array.isArray(installment.payments) ? installment.payments : [];
  const regDate = installment.registrationDate ? installment.registrationDate.replace(/-/g, '/') : '—';
  const nextDue = installment.nextDueDate ? installment.nextDueDate.replace(/-/g, '/') : '—';

  const now = new Date();
  const dateStr = `${now.getFullYear()}/${String(now.getMonth() + 1).padStart(2, '0')}/${String(now.getDate()).padStart(2, '0')}`;

  let text = `كشف عقد قسط\n\n`;
  text += `الحساب: ${branchName}\n`;
  text += `المستخدم: ${userName}\n`;
  text += `التاريخ: ${dateStr}\n\n`;
  text += `━━━━━━━━━━━━━━\n\n`;

  text += `العميل: ${installment.name}\n`;
  text += `الهاتف: ${installment.phone || 'غير مسجل'}\n`;
  text += `السلعة: ${installment.item || 'غير محدد'}\n`;
  text += `قيمة العقد الكلية: ${Number(installment.totalAmount).toLocaleString('en-US')} ${currencySymbol}\n`;
  text += `المقدم المدفوع: ${Number(installment.downPayment || 0).toLocaleString('en-US')} ${currencySymbol}\n`;
  text += `المتبقي المطلوب: ${Number(installment.remainingAmount).toLocaleString('en-US')} ${currencySymbol}\n`;
  if (installment.monthlyInstallmentAmount) {
    text += `القسط الشهري: ${Number(installment.monthlyInstallmentAmount).toLocaleString('en-US')} ${currencySymbol}\n`;
  }
  text += `تاريخ العقد: ${regDate}\n`;
  text += `القسط القادم: ${nextDue}\n`;
  text += `الحالة: ${statusLabel}\n\n`;

  text += `الدفعات المسددة:\n`;
  if (payments.length > 0) {
    payments.forEach((p) => {
      const pDate = p.date ? p.date.split('T')[0].replace(/-/g, '/') : '';
      const pNote = p.notes ? ` - ${p.notes}` : '';
      text += `• دفعة قسط: ${Number(p.amount).toLocaleString('en-US')} ${currencySymbol} (${pDate}${pNote})\n`;
    });
  } else {
    text += `• لم تسدد دفعات بعد (تم دفع المقدم فقط)\n`;
  }

  text += `\n━━━━━━━━━━━━━━\n\n`;
  text += `المتبقي النهائي: ${Number(installment.remainingAmount).toLocaleString('en-US')} ${currencySymbol}\n\n`;
  text += `نظام دفتر الديون والأقساط والموردين`;

  return text;
};

// ----------------------------------------------------
// 7. GENERATE SINGLE SUPPLIER TEXT (Clean - No Emojis)
// ----------------------------------------------------
export const generateSingleSupplierTextReport = (
  supplier: Supplier,
  options: TextReportExportOptions = {}
): string => {
  const { branchName = 'الفرع الرئيسي', userName = 'المسؤول', currencySymbol = 'د.ع' } = options;
  const curDebt = Number(supplier.amount) || Number(supplier.totalDebt) || 0;
  const isCleared = curDebt === 0;
  const statusLabel = isCleared ? 'حساب خالص ومسدد' : 'نشط (يوجد رصيد)';
  const history = Array.isArray(supplier.history) ? supplier.history : [];
  const lastDate = supplier.lastTransactionDate ? supplier.lastTransactionDate.split('T')[0].replace(/-/g, '/') : '—';

  const now = new Date();
  const dateStr = `${now.getFullYear()}/${String(now.getMonth() + 1).padStart(2, '0')}/${String(now.getDate()).padStart(2, '0')}`;

  let text = `كشف حساب مورد\n\n`;
  text += `الحساب: ${branchName}\n`;
  text += `المستخدم: ${userName}\n`;
  text += `التاريخ: ${dateStr}\n\n`;
  text += `━━━━━━━━━━━━━━\n\n`;

  text += `المورد: ${supplier.name}${supplier.companyName ? ` (${supplier.companyName})` : ''}\n`;
  text += `الهاتف: ${supplier.phone || 'غير مسجل'}\n`;
  if (supplier.itemType) {
    text += `نوع البضاعة: ${supplier.itemType}\n`;
  }
  text += `المتبقي له في ذمتنا: ${curDebt.toLocaleString('en-US')} ${currencySymbol}\n`;
  text += `إجمالي المسدد له: ${Number(supplier.totalPaid || 0).toLocaleString('en-US')} ${currencySymbol}\n`;
  text += `الحالة: ${statusLabel}\n`;
  text += `آخر حركة: ${lastDate}\n\n`;

  text += `الفواتير والدفعات:\n`;
  if (history.length > 0) {
    history.forEach((tx) => {
      const isPay = tx.type === 'pay_supplier' || tx.type === 'pay';
      const typeStr = isPay ? 'سداد دفعة: -' : 'فاتورة توريد: +';
      const noteStr = tx.notes || tx.description ? ` (${tx.notes || tx.description})` : '';
      text += `• ${typeStr}${Number(tx.amount).toLocaleString('en-US')} ${currencySymbol}${noteStr}\n`;
    });
  } else {
    text += `• لا توجد حركات تفصيلية مسجلة\n`;
  }

  text += `\n━━━━━━━━━━━━━━\n\n`;
  text += `الرصيد الحالي للمورد: ${curDebt.toLocaleString('en-US')} ${currencySymbol}\n\n`;
  text += `نظام دفتر الديون والأقساط والموردين`;

  return text;
};

// ----------------------------------------------------
// 8. GENERATE FULL BRANCH MASTER TEXT REPORT
// ----------------------------------------------------
export const generateFullBranchMasterTextReport = ({
  debtors = [],
  installments = [],
  suppliers = [],
  historyMap = {},
  options = {},
}: {
  debtors?: Debtor[];
  installments?: InstallmentRecord[];
  suppliers?: Supplier[];
  historyMap?: Record<string, DebtorTransaction[]>;
  options?: TextReportExportOptions;
}): string => {
  const { branchName = 'الفرع الرئيسي', userName = 'المسؤول', currencySymbol = 'د.ع' } = options;

  const realDebtors = (debtors || []).filter((d) => !d.isDemo && d.type !== 'creditor');
  const myCreditors = (debtors || []).filter((d) => !d.isDemo && d.type === 'creditor');
  const realInstallments = (installments || []).filter((i) => !i.isDemo);
  const realSuppliers = (suppliers || []).filter((s) => !s.isDemo);

  const totalDebt = realDebtors.reduce((sum, d) => sum + (Number(d.amount) || 0), 0);
  const totalCreditors = myCreditors.reduce((sum, c) => sum + (Number(c.amount) || 0), 0);
  const totalInstallmentsRem = realInstallments.reduce((sum, i) => sum + (Number(i.remainingAmount) || 0), 0);
  const totalSuppliersDebt = realSuppliers.reduce((sum, s) => sum + (Number(s.amount) || 0), 0);

  const now = new Date();
  const dateStr = `${now.getFullYear()}/${String(now.getMonth() + 1).padStart(2, '0')}/${String(now.getDate()).padStart(2, '0')}`;

  let text = `========================================\n`;
  text += `كشف الحسابات والنسخة الاحتياطية الشاملة\n`;
  text += `========================================\n`;
  text += `الفرع: ${branchName}\n`;
  text += `المدير: ${userName}\n`;
  text += `التاريخ: ${dateStr}\n\n`;

  text += `الخلاصة المالية العامة:\n`;
  text += `- ديون العملاء المطلوب تحصيلها (${realDebtors.length} عميل): ${totalDebt.toLocaleString('en-US')} ${currencySymbol}\n`;
  text += `- الدائنين المطلوب سدادها لهم (${myCreditors.length} دائن): ${totalCreditors.toLocaleString('en-US')} ${currencySymbol}\n`;
  text += `- متبقي عقود الأقساط (${realInstallments.length} عقد): ${totalInstallmentsRem.toLocaleString('en-US')} ${currencySymbol}\n`;
  text += `- مستحقات الموردين والشركات (${realSuppliers.length} مورد): ${totalSuppliersDebt.toLocaleString('en-US')} ${currencySymbol}\n`;
  text += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;

  // 1. Debtors
  text += `[ 1. سجلات ديون العملاء ]\n\n`;
  if (realDebtors.length === 0) {
    text += `لا توجد ديون مسجلة على العملاء.\n\n`;
  } else {
    realDebtors.forEach((d, idx) => {
      text += `${idx + 1}. العميل: ${d.name} | الهاتف: ${d.phone || 'غير مسجل'}\n`;
      text += `   المبلغ المطلوب منه: ${Number(d.amount).toLocaleString('en-US')} ${currencySymbol}\n`;
      const h = historyMap[String(d.id)] || d.history || [];
      if (h.length > 0) {
        h.slice(-10).forEach((tx) => {
          const sign = tx.type === 'pay' ? 'تسديد دفعة: -' : tx.type === 'initial' ? 'رصيد افتتاحي: ' : 'دين جديد: +';
          const payMethodLabel = tx.paymentMethod === 'electronic' ? '[دفع إلكتروني]' : '[نقد كاش]';
          const noteStr = tx.notes || tx.description ? ` (${tx.notes || tx.description})` : '';
          text += `   - ${sign}${Number(tx.amount).toLocaleString('en-US')} ${currencySymbol} ${payMethodLabel} (${tx.date ? tx.date.split('T')[0] : ''})${noteStr}\n`;
        });
      }
      text += `\n`;
    });
  }

  // 2. Creditors
  text += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
  text += `[ 2. سجلات الدائنين - ديون عليّ للآخرين ]\n\n`;
  if (myCreditors.length === 0) {
    text += `لا توجد ديون مستحقة عليك للآخرين.\n\n`;
  } else {
    myCreditors.forEach((c, idx) => {
      text += `${idx + 1}. الدائن: ${c.name} | الهاتف: ${c.phone || 'غير مسجل'}\n`;
      text += `   المبلغ المستحق له: ${Number(c.amount).toLocaleString('en-US')} ${currencySymbol}\n`;
      const h = historyMap[String(c.id)] || c.history || [];
      if (h.length > 0) {
        h.slice(-10).forEach((tx) => {
          const sign = tx.type === 'pay' ? 'سداد دفعة له: -' : 'استدانة مبلغ: +';
          const payMethodLabel = tx.paymentMethod === 'electronic' ? '[دفع إلكتروني]' : '[نقد كاش]';
          const noteStr = tx.notes || tx.description ? ` (${tx.notes || tx.description})` : '';
          text += `   - ${sign}${Number(tx.amount).toLocaleString('en-US')} ${currencySymbol} ${payMethodLabel} (${tx.date ? tx.date.split('T')[0] : ''})${noteStr}\n`;
        });
      }
      text += `\n`;
    });
  }

  // 3. Installments
  text += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
  text += `[ 3. عقود نظام الأقساط ]\n\n`;
  if (realInstallments.length === 0) {
    text += `لا توجد عقود أقساط مسجلة.\n\n`;
  } else {
    realInstallments.forEach((inst, idx) => {
      text += `${idx + 1}. صاحب القسط: ${inst.name} | السلعة: ${inst.item}\n`;
      text += `   المتبقي: ${Number(inst.remainingAmount).toLocaleString('en-US')} من إجمالي ${Number(inst.totalAmount).toLocaleString('en-US')} ${currencySymbol}\n`;
      text += `   الهاتف: ${inst.phone || 'غير مسجل'} | الاستحقاق: ${inst.nextDueDate || '—'}\n`;
      const payments = Array.isArray(inst.payments) ? inst.payments : [];
      if (payments.length > 0) {
        payments.slice(-5).forEach((p) => {
          const payMethodLabel = p.paymentMethod === 'electronic' ? '[دفع إلكتروني]' : '[نقد كاش]';
          text += `   - تسديد قسط: +${Number(p.amount).toLocaleString('en-US')} ${currencySymbol} ${payMethodLabel} (${p.date ? p.date.split('T')[0] : ''})\n`;
        });
      }
      text += `\n`;
    });
  }

  // 4. Suppliers
  text += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
  text += `[ 4. حسابات الموردين والشركات ]\n\n`;
  if (realSuppliers.length === 0) {
    text += `لا يوجد موردين مسجلين.\n\n`;
  } else {
    realSuppliers.forEach((s, idx) => {
      text += `${idx + 1}. المورد: ${s.name}${s.companyName ? ` (${s.companyName})` : ''}\n`;
      text += `   المستحق له: ${(Number(s.amount) || Number(s.totalDebt) || 0).toLocaleString('en-US')} ${currencySymbol} | الهاتف: ${s.phone || 'غير مسجل'}\n`;
      const history = Array.isArray(s.history) ? s.history : [];
      if (history.length > 0) {
        history.slice(-5).forEach((tx) => {
          const sign = tx.type === 'pay_supplier' || tx.type === 'pay' ? 'سداد دفعة: -' : 'فاتورة توريد: +';
          const payMethodLabel = tx.paymentMethod === 'electronic' ? '[دفع إلكتروني]' : '[نقد كاش]';
          text += `   - ${sign}${Number(tx.amount).toLocaleString('en-US')} ${currencySymbol} ${payMethodLabel} (${tx.date ? tx.date.split('T')[0] : ''})\n`;
        });
      }
      text += `\n`;
    });
  }

  text += `========================================\n`;
  text += `تم التصدير بنجاح عبر تطبيق دفتر الديون والأقساط والموردين\n`;
  text += `========================================\n`;

  return text;
};
