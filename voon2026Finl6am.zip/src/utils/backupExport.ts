import { AppSettings, Debtor, User, InstallmentRecord, Manager, Supplier } from '../types';
import { getLocalDebtorHistory, sanitizeSupplier, queryTurso } from '../services/turso';
import { computeIntegrityHash, getSecuredPassword } from './sanitize';
import { exportFullBranchMasterPdf } from './pdfReportGenerator';
import { generateFullBranchMasterTextReport, shareTextFile } from './textReportExporter';

export const getBackupTimestampKey = (userId: number) => `aldion_last_manual_backup_${userId}`;

export const getFirstLoginTimestampKey = (userId: number) => `aldion_first_login_time_${userId}`;

/**
 * Checks whether a sub-manager is required to take a manual backup.
 * 1. If account is brand new and has fewer than 5 operations, do not prompt yet.
 * 2. If account has 5+ operations or already has a backup history, prompt if 3 days have passed.
 */
export const checkManualBackupDue = (
  userId: number,
  daysThreshold: number = 3,
  totalOperationsCount: number = 0
): { isDue: boolean; daysPassed: number; lastDateStr: string | null; isNewAccountWaiting?: boolean } => {
  try {
    const raw = localStorage.getItem(getBackupTimestampKey(userId));
    if (!raw) {
      // If brand new account with less than 5 operations, wait until 5 operations are registered
      if (totalOperationsCount < 5) {
        return { isDue: false, daysPassed: 0, lastDateStr: null, isNewAccountWaiting: true };
      }
      // If reached 5+ operations, prompt for first backup
      return { isDue: true, daysPassed: daysThreshold, lastDateStr: null, isNewAccountWaiting: false };
    }

    const lastTime = new Date(raw).getTime();
    if (isNaN(lastTime)) {
      if (totalOperationsCount < 5) {
        return { isDue: false, daysPassed: 0, lastDateStr: null, isNewAccountWaiting: true };
      }
      return { isDue: true, daysPassed: daysThreshold, lastDateStr: null, isNewAccountWaiting: false };
    }

    const diffMs = Date.now() - lastTime;
    const daysPassed = Math.floor(diffMs / (1000 * 60 * 60 * 24));
    return {
      isDue: daysPassed >= daysThreshold,
      daysPassed,
      lastDateStr: new Date(lastTime).toLocaleDateString('ar-IQ'),
      isNewAccountWaiting: false,
    };
  } catch {
    return { isDue: false, daysPassed: 0, lastDateStr: null };
  }
};

/**
 * Saves the backup timestamp to the cloud database (users table)
 */
export const syncBackupDateToCloud = async (userId: number, dateIso: string) => {
  if (!userId || userId === 999999) return;
  try {
    await queryTurso("UPDATE users SET last_backup_date = ? WHERE id = ?;", [dateIso, userId]);
  } catch {
    try {
      await queryTurso("ALTER TABLE users ADD COLUMN last_backup_date TEXT;");
      await queryTurso("UPDATE users SET last_backup_date = ? WHERE id = ?;", [dateIso, userId]);
    } catch (e) {
      console.warn("Cloud backup date sync warning:", e);
    }
  }
};

/**
 * Fetches the backup timestamp from the cloud database and syncs with local storage
 */
export const fetchBackupDateFromCloud = async (userId: number): Promise<string | null> => {
  if (!userId || userId === 999999) return null;
  try {
    let res;
    try {
      res = await queryTurso("SELECT last_backup_date FROM users WHERE id = ?;", [userId]);
    } catch {
      await queryTurso("ALTER TABLE users ADD COLUMN last_backup_date TEXT;").catch(() => {});
      res = await queryTurso("SELECT last_backup_date FROM users WHERE id = ?;", [userId]);
    }

    if (res?.results?.[0]?.response?.result?.rows?.[0]?.[0]?.value) {
      const cloudDate = String(res.results[0].response.result.rows[0][0].value).trim();
      if (cloudDate) {
        const localRaw = localStorage.getItem(getBackupTimestampKey(userId));
        if (!localRaw || new Date(cloudDate).getTime() > new Date(localRaw).getTime()) {
          localStorage.setItem(getBackupTimestampKey(userId), cloudDate);
        }
        return cloudDate;
      }
    }
  } catch (err) {
    console.warn("Could not fetch cloud backup date:", err);
  }
  return null;
};

export const recordManualBackupSuccess = (userId: number) => {
  const nowIso = new Date().toISOString();
  try {
    localStorage.setItem(getBackupTimestampKey(userId), nowIso);
  } catch (e) {
    console.warn('Failed to record backup timestamp in localStorage:', e);
  }
  syncBackupDateToCloud(userId, nowIso).catch(() => {});
};

export interface ExportBackupParams {
  currentUser: User;
  debtors: Debtor[];
  installments?: InstallmentRecord[];
  suppliers?: Supplier[];
  managers?: Manager[];
  settings: AppSettings;
}

export interface ExportBackupResult {
  success: boolean;
  fileName: string;
  summary: {
    debtorsCount: number;
    creditorsCount: number;
    installmentsCount: number;
    suppliersCount: number;
    managersCount: number;
  };
}

/**
 * 1. Share backup as official, multi-page Master PDF document
 */
export const shareBackupPdf = async ({
  currentUser,
  debtors = [],
  installments = [],
  suppliers = [],
  settings,
}: ExportBackupParams): Promise<ExportBackupResult> => {
  const realDebtors = (debtors || []).filter((d) => !d.isDemo);
  const myDebtors = realDebtors.filter((d) => d.type !== 'creditor');
  const myCreditors = realDebtors.filter((d) => d.type === 'creditor');
  const realInstallments = (installments || []).filter((i) => !i.isDemo);
  const realSuppliers = (suppliers || []).filter((s) => !s.isDemo);

  exportFullBranchMasterPdf({
    currentUser,
    debtors,
    installments,
    suppliers,
    numberFormat: settings.numberFormat || 'english',
  });

  recordManualBackupSuccess(currentUser.id);

  return {
    success: true,
    fileName: `كشف_حسابات_${currentUser.branch_name || currentUser.username}_${new Date().toISOString().slice(0, 10)}.pdf`,
    summary: {
      debtorsCount: myDebtors.length,
      creditorsCount: myCreditors.length,
      installmentsCount: realInstallments.length,
      suppliersCount: realSuppliers.length,
      managersCount: 0,
    },
  };
};

/**
 * 2. Share backup as clean, full TXT Statement (opens WhatsApp / Share Sheet)
 */
export const shareBackupTxt = async ({
  currentUser,
  debtors = [],
  installments = [],
  suppliers = [],
  settings,
}: ExportBackupParams): Promise<ExportBackupResult> => {
  const realDebtors = (debtors || []).filter((d) => !d.isDemo);
  const myDebtors = realDebtors.filter((d) => d.type !== 'creditor');
  const myCreditors = realDebtors.filter((d) => d.type === 'creditor');
  const realInstallments = (installments || []).filter((i) => !i.isDemo);
  const realSuppliers = (suppliers || []).filter((s) => !s.isDemo);

  const historyMap = getLocalDebtorHistory(currentUser.id);
  const textContent = generateFullBranchMasterTextReport({
    debtors,
    installments,
    suppliers,
    historyMap,
    options: {
      branchName: currentUser.branch_name || currentUser.username,
      userName: currentUser.username,
      currencySymbol: settings.currency || 'د.ع',
    },
  });

  const dateStr = new Date().toISOString().slice(0, 10);
  const cleanBranch = (currentUser.branch_name || currentUser.username || 'branch').trim().replace(/[\s/\\:*?"<>|]+/g, '_');
  const fileName = `backup_text_${cleanBranch}_${dateStr}.txt`;
  const shareTitle = `نسخة كشف الحسابات - ${currentUser.branch_name || currentUser.username}`;

  await shareTextFile(textContent, fileName, shareTitle);

  recordManualBackupSuccess(currentUser.id);

  return {
    success: true,
    fileName,
    summary: {
      debtorsCount: myDebtors.length,
      creditorsCount: myCreditors.length,
      installmentsCount: realInstallments.length,
      suppliersCount: realSuppliers.length,
      managersCount: 0,
    },
  };
};

/**
 * 3. Share or Download backup as JSON file with SHA-256 integrity hash
 */
export const executeExportBackup = async ({
  currentUser,
  debtors,
  installments = [],
  suppliers = [],
  managers = [],
  settings,
}: ExportBackupParams): Promise<ExportBackupResult> => {
  const isAdmin = currentUser.role === 'admin';
  const realDebtors = (debtors || []).filter((d) => !d.isDemo);
  const historyMap = getLocalDebtorHistory(currentUser.id);
  const enrichedDebtors = realDebtors.map((d) => ({
    ...d,
    history: historyMap[d.id] || d.history || [],
    type: d.type || 'debtor',
  }));

  const myDebtors = enrichedDebtors.filter((d) => d.type !== 'creditor');
  const myCreditors = enrichedDebtors.filter((d) => d.type === 'creditor');

  const totalDebt = myDebtors.reduce((sum, d) => sum + (Number(d.amount) || 0), 0);
  const totalCreditorDebt = myCreditors.reduce((sum, d) => sum + (Number(d.amount) || 0), 0);

  const realInstallments = (installments || []).map((inst) => ({
    ...inst,
    payments: Array.isArray(inst.payments) ? inst.payments : [],
  }));
  const totalInstallmentsAmount = realInstallments.reduce(
    (sum, i) => sum + (Number(i.totalAmount) || 0),
    0
  );
  const totalInstallmentsRemaining = realInstallments.reduce(
    (sum, i) => sum + (Number(i.remainingAmount) || 0),
    0
  );

  const realSuppliers = (suppliers || []).filter((s) => !s.isDemo).map(sanitizeSupplier);
  const totalSuppliersDebt = realSuppliers.reduce(
    (sum, s) => sum + (Number(s.amount) || Number(s.totalDebt) || 0),
    0
  );

  const realManagers = isAdmin
    ? (managers || []).map((m) => ({
        id: m.id,
        username: m.username,
        branch: m.branch,
        isActive: m.isActive,
        subscriptionType: m.subscriptionType,
        subscriptionExpiresAt: m.subscriptionExpiresAt,
        allowedModules: m.allowedModules,
        plainPassword:
          m.plainPassword ||
          getSecuredPassword(m.id) ||
          getSecuredPassword(m.username) ||
          '',
        createdAt: m.createdAt,
      }))
    : [];

  const now = new Date();
  const dateStr = now.toISOString().slice(0, 10);

  const integrityChecksum = await computeIntegrityHash({
    debtorsCount: enrichedDebtors.length,
    installmentsCount: realInstallments.length,
    suppliersCount: realSuppliers.length,
    managersCount: realManagers.length,
    totalDebt,
    totalCreditorDebt,
    exportTimestamp: now.toISOString(),
  });

  const backupPayload = {
    appName: 'دفتر الديون والأقساط والموردين والدائنين',
    version: '3.5',
    backupType: isAdmin ? 'full_system' : 'branch_local',
    exportTimestamp: now.toISOString(),
    integrityChecksum,
    branchName: currentUser.branch_name || (isAdmin ? 'Main Branch' : currentUser.username),
    username: currentUser.username,
    userId: currentUser.id,
    userRole: currentUser.role,
    totalManagersCount: realManagers.length,
    totalDebtorsCount: myDebtors.length,
    totalCreditorsCount: myCreditors.length,
    totalDebtAmount: totalDebt,
    totalCreditorDebtAmount: totalCreditorDebt,
    totalInstallmentsCount: realInstallments.length,
    totalInstallmentsAmount,
    totalInstallmentsRemaining,
    totalSuppliersCount: realSuppliers.length,
    totalSuppliersDebtAmount: totalSuppliersDebt,
    settings,
    ...(isAdmin ? { managers: realManagers } : {}),
    debtors: enrichedDebtors,
    installments: realInstallments,
    suppliers: realSuppliers,
  };

  const jsonStr = JSON.stringify(backupPayload, null, 2);
  const blob = new Blob([jsonStr], { type: 'application/json;charset=utf-8;' });

  const cleanBranchFile = (currentUser.branch_name || currentUser.username || 'branch')
    .trim()
    .replace(/[\s/\\:*?"<>|]+/g, '_');
  const fileName = isAdmin
    ? `backup_full_system_${dateStr}.json`
    : `backup_branch_${cleanBranchFile}_${dateStr}.json`;

  // Try Native Share API if available
  let sharedNatively = false;
  if (typeof navigator !== 'undefined' && navigator.share) {
    try {
      const file = new File([blob], fileName, { type: 'application/json' });
      if (navigator.canShare && navigator.canShare({ files: [file] })) {
        await navigator.share({
          files: [file],
          title: `نسخة احتياطية - ${currentUser.branch_name || currentUser.username}`,
          text: `ملف النسخة الاحتياطية المشفرة - ${currentUser.branch_name || currentUser.username}`,
        });
        sharedNatively = true;
      }
    } catch (e: any) {
      if (e?.name === 'AbortError') {
        sharedNatively = true;
      }
    }
  }

  if (!sharedNatively) {
    const url = URL.createObjectURL(blob);
    const downloadLink = document.createElement('a');
    downloadLink.href = url;
    downloadLink.download = fileName;
    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);
    URL.revokeObjectURL(url);
  }

  // Record successful backup date
  recordManualBackupSuccess(currentUser.id);

  return {
    success: true,
    fileName,
    summary: {
      debtorsCount: myDebtors.length,
      creditorsCount: myCreditors.length,
      installmentsCount: realInstallments.length,
      suppliersCount: realSuppliers.length,
      managersCount: realManagers.length,
    },
  };
};
