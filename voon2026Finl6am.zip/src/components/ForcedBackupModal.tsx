import React, { useState } from 'react';
import { AppSettings, Debtor, InstallmentRecord, Manager, Supplier, User } from '../types';
import { executeExportBackup } from '../utils/backupExport';
import { formatNumber } from '../utils/formatters';

interface ForcedBackupModalProps {
  isOpen: boolean;
  currentUser: User;
  debtors: Debtor[];
  installments?: InstallmentRecord[];
  suppliers?: Supplier[];
  managers?: Manager[];
  settings: AppSettings;
  daysPassed: number;
  lastDateStr: string | null;
  onBackupSuccess: () => void;
  onShowToast: (message: string, type: 'success' | 'error' | 'info') => void;
}

export const ForcedBackupModal: React.FC<ForcedBackupModalProps> = ({
  isOpen,
  currentUser,
  debtors,
  installments = [],
  suppliers = [],
  managers = [],
  settings,
  daysPassed,
  lastDateStr,
  onBackupSuccess,
  onShowToast,
}) => {
  const [isSharingJson, setIsSharingJson] = useState(false);

  if (!isOpen) return null;

  const realDebtors = (debtors || []).filter((d) => !d.isDemo);
  const myDebtors = realDebtors.filter((d) => d.type !== 'creditor');
  const myCreditors = realDebtors.filter((d) => d.type === 'creditor');
  const realInstallments = (installments || []).filter((i) => !i.isDemo);
  const realSuppliers = (suppliers || []).filter((s) => !s.isDemo);

  const handleShareJson = async () => {
    try {
      setIsSharingJson(true);
      const res = await executeExportBackup({
        currentUser,
        debtors,
        installments,
        suppliers,
        managers,
        settings,
      });
      if (res.success) {
        onShowToast('تم حفظ وتصدير ملف النسخة الاحتياطية (JSON) بنجاح', 'success');
        onBackupSuccess();
      }
    } catch (err: any) {
      console.error('Share JSON error:', err);
      onShowToast(`حدث خطأ أثناء إعداد النسخة: ${err?.message || 'خطأ غير معروف'}`, 'error');
    } finally {
      setIsSharingJson(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-[99999] flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-sm select-none animate-fadeIn"
      dir="rtl"
      role="dialog"
      aria-modal="true"
    >
      <div className="bg-white dark:bg-slate-900 border border-amber-300/80 dark:border-amber-600/40 rounded-2xl max-w-[380px] w-full shadow-2xl overflow-hidden animate-scaleUp">
        {/* Compact Modern Header */}
        <div className="flex items-center gap-3 px-4 py-3.5 bg-gradient-to-r from-amber-500 to-orange-500 text-white">
          <div className="w-8 h-8 rounded-lg bg-white/20 backdrop-blur-sm flex items-center justify-center shrink-0 shadow-inner">
            <svg
              className="w-4.5 h-4.5 text-white"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              strokeWidth={2.2}
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"
              />
            </svg>
          </div>
          <div className="flex-1 min-w-0">
            <h2 className="text-sm font-bold leading-tight">حماية إضافية لبياناتك</h2>
            <p className="text-[11px] text-amber-100 truncate mt-0.5">
              الفرع: {currentUser.branch_name || currentUser.username}
            </p>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-4 space-y-3 text-slate-700 dark:text-slate-200 text-right">
          {/* Main Notice Box */}
          <div className="bg-amber-50/90 dark:bg-amber-950/30 border border-amber-200/80 dark:border-amber-800/50 rounded-xl p-3 text-[12px] leading-relaxed text-amber-950 dark:text-amber-100">
            <p className="text-[11.5px] leading-5 text-amber-950 dark:text-amber-100 font-normal">
              <span className="font-bold text-amber-900 dark:text-amber-300 block mb-1">
                بياناتك محفوظة سحابيًا، لكن لا تعتمد على نسخة واحدة فقط.
              </span>
              احفظ نسخة احتياطية من بياناتك على هاتفك بشكل دوري، لتبقى لديك نسخة مستقلة يمكنك استخدامها لاستعادة بياناتك كاملة إذا حدثت مشكلة في الخادم أو مزود الخدمة أو فقدان البيانات بشكل غير متوقع.
            </p>
            {lastDateStr && (
              <div className="mt-2 pt-1.5 border-t border-amber-200/60 dark:border-amber-800/40 text-[10.5px] text-amber-800 dark:text-amber-400 font-mono">
                آخر نسخة محفوظة محلياً: {lastDateStr}
              </div>
            )}
          </div>

          {/* Compact Single-Row Stats Strip */}
          <div className="grid grid-cols-4 gap-1.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/70 rounded-lg p-2 text-center">
            <div className="min-w-0">
              <span className="text-[10px] text-slate-500 dark:text-slate-400 block truncate">المدينين</span>
              <span className="font-bold text-blue-600 dark:text-blue-400 font-mono text-xs">
                {formatNumber(myDebtors.length)}
              </span>
            </div>
            <div className="min-w-0 border-r border-slate-200 dark:border-slate-700 pr-1">
              <span className="text-[10px] text-slate-500 dark:text-slate-400 block truncate">ديون عليّ</span>
              <span className="font-bold text-rose-600 dark:text-rose-400 font-mono text-xs">
                {formatNumber(myCreditors.length)}
              </span>
            </div>
            <div className="min-w-0 border-r border-slate-200 dark:border-slate-700 pr-1">
              <span className="text-[10px] text-slate-500 dark:text-slate-400 block truncate">الأقساط</span>
              <span className="font-bold text-purple-600 dark:text-purple-400 font-mono text-xs">
                {formatNumber(realInstallments.length)}
              </span>
            </div>
            <div className="min-w-0 border-r border-slate-200 dark:border-slate-700 pr-1">
              <span className="text-[10px] text-slate-500 dark:text-slate-400 block truncate">الموردين</span>
              <span className="font-bold text-amber-600 dark:text-amber-400 font-mono text-xs">
                {formatNumber(realSuppliers.length)}
              </span>
            </div>
          </div>

          {/* Compact Action Button */}
          <button
            onClick={handleShareJson}
            disabled={isSharingJson}
            className="w-full py-2.5 px-3 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 active:scale-[0.99] text-white font-bold rounded-xl shadow-md shadow-orange-600/20 flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-75 disabled:cursor-not-allowed text-xs sm:text-sm mt-1"
          >
            {isSharingJson ? (
              <>
                <svg className="animate-spin h-4 w-4 text-white" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z" />
                </svg>
                <span>جاري حفظ وتصدير النسخة...</span>
              </>
            ) : (
              <>
                <svg className="w-4 h-4 text-amber-200 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
                </svg>
                <span>حفظ وتصدير نسخة احتياطية على هاتفك (JSON)</span>
              </>
            )}
          </button>

          <p className="text-center text-[10px] text-slate-500 dark:text-slate-400 flex items-center justify-center gap-1 pt-0.5">
            <svg className="w-3 h-3 text-slate-400 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
            </svg>
            <span>يتم حفظ ملف مشفر ومستقل يمكنك مشاركته أو حفظه محلياً</span>
          </p>
        </div>
      </div>
    </div>
  );
};
