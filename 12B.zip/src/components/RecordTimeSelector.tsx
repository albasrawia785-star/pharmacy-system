import React, { useEffect, useState } from 'react';
import { getCurrentTimeStr, toEnglishDigits, formatTimeOnly } from '../utils/formatters';

export interface RecordTimeSelectorProps {
  enabled: boolean;
  onEnabledChange: (enabled: boolean) => void;
  mode: 'auto' | 'manual';
  onModeChange: (mode: 'auto' | 'manual') => void;
  time: string; // HH:mm
  onTimeChange: (time: string) => void;
  accentColor?: 'blue' | 'emerald' | 'amber' | 'teal' | 'rose' | 'indigo';
  className?: string;
  idPrefix?: string;
}

export const RecordTimeSelector: React.FC<RecordTimeSelectorProps> = ({
  enabled,
  onEnabledChange,
  mode,
  onModeChange,
  time,
  onTimeChange,
  accentColor = 'blue',
  className = '',
  idPrefix = 'rec_time',
}) => {
  const [currentTimeSample, setCurrentTimeSample] = useState(() => getCurrentTimeStr());

  // Keep auto-time sample updated every few seconds when visible
  useEffect(() => {
    if (!enabled) return;
    const updateSample = () => setCurrentTimeSample(getCurrentTimeStr());
    updateSample();
    const timer = setInterval(updateSample, 5000);
    return () => clearInterval(timer);
  }, [enabled]);

  // Color schemes
  const colorMap = {
    blue: {
      accent: 'accent-blue-600',
      activeTab: 'bg-blue-600 text-white shadow-xs',
      inactiveTab: 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700',
      border: 'border-blue-200 dark:border-blue-800/60',
      bg: 'bg-blue-50/50 dark:bg-blue-950/20',
      icon: 'text-blue-600 dark:text-blue-400',
      focusRing: 'focus:border-blue-500 focus:ring-blue-500/20',
      nowBtn: 'text-blue-600 hover:text-blue-700 bg-blue-50 dark:bg-blue-950/40 hover:bg-blue-100',
    },
    emerald: {
      accent: 'accent-emerald-600',
      activeTab: 'bg-emerald-600 text-white shadow-xs',
      inactiveTab: 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700',
      border: 'border-emerald-200 dark:border-emerald-800/60',
      bg: 'bg-emerald-50/50 dark:bg-emerald-950/20',
      icon: 'text-emerald-600 dark:text-emerald-400',
      focusRing: 'focus:border-emerald-500 focus:ring-emerald-500/20',
      nowBtn: 'text-emerald-600 hover:text-emerald-700 bg-emerald-50 dark:bg-emerald-950/40 hover:bg-emerald-100',
    },
    amber: {
      accent: 'accent-amber-600',
      activeTab: 'bg-amber-600 text-white shadow-xs',
      inactiveTab: 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700',
      border: 'border-amber-200 dark:border-amber-800/60',
      bg: 'bg-amber-50/50 dark:bg-amber-950/20',
      icon: 'text-amber-600 dark:text-amber-400',
      focusRing: 'focus:border-amber-500 focus:ring-amber-500/20',
      nowBtn: 'text-amber-700 hover:text-amber-800 bg-amber-50 dark:bg-amber-950/40 hover:bg-amber-100',
    },
    teal: {
      accent: 'accent-teal-600',
      activeTab: 'bg-teal-600 text-white shadow-xs',
      inactiveTab: 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700',
      border: 'border-teal-200 dark:border-teal-800/60',
      bg: 'bg-teal-50/50 dark:bg-teal-950/20',
      icon: 'text-teal-600 dark:text-teal-400',
      focusRing: 'focus:border-teal-500 focus:ring-teal-500/20',
      nowBtn: 'text-teal-600 hover:text-teal-700 bg-teal-50 dark:bg-teal-950/40 hover:bg-teal-100',
    },
    rose: {
      accent: 'accent-rose-600',
      activeTab: 'bg-rose-600 text-white shadow-xs',
      inactiveTab: 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700',
      border: 'border-rose-200 dark:border-rose-800/60',
      bg: 'bg-rose-50/50 dark:bg-rose-950/20',
      icon: 'text-rose-600 dark:text-rose-400',
      focusRing: 'focus:border-rose-500 focus:ring-rose-500/20',
      nowBtn: 'text-rose-600 hover:text-rose-700 bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100',
    },
    indigo: {
      accent: 'accent-indigo-600',
      activeTab: 'bg-indigo-600 text-white shadow-xs',
      inactiveTab: 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700',
      border: 'border-indigo-200 dark:border-indigo-800/60',
      bg: 'bg-indigo-50/50 dark:bg-indigo-950/20',
      icon: 'text-indigo-600 dark:text-indigo-400',
      focusRing: 'focus:border-indigo-500 focus:ring-indigo-500/20',
      nowBtn: 'text-indigo-600 hover:text-indigo-700 bg-indigo-50 dark:bg-indigo-950/40 hover:bg-indigo-100',
    },
  };

  const currentTheme = colorMap[accentColor] || colorMap.blue;

  return (
    <div className={`space-y-2 text-start ${className}`}>
      {/* Checkbox: تسجيل الوقت */}
      <div className="flex items-center justify-between">
        <label
          htmlFor={`${idPrefix}_checkbox`}
          className="inline-flex items-center gap-2 cursor-pointer select-none text-xs font-bold text-slate-700 dark:text-slate-200"
        >
          <input
            type="checkbox"
            id={`${idPrefix}_checkbox`}
            checked={enabled}
            onChange={(e) => {
              const val = e.target.checked;
              onEnabledChange(val);
              if (val && !time) {
                onTimeChange(getCurrentTimeStr());
              }
            }}
            className={`w-4 h-4 rounded border-slate-300 dark:border-slate-600 cursor-pointer ${currentTheme.accent}`}
          />
          <span className="flex items-center gap-1.5">
            <i className={`fa-regular fa-clock text-xs ${currentTheme.icon}`}></i>
            <span>تسجيل الوقت</span>
          </span>
        </label>

        {enabled && (
          <span className="text-[10px] text-slate-400 dark:text-slate-500 font-medium">
            {mode === 'auto' ? 'تلقائي (وقت الجهاز)' : 'يدوي (محدد)'}
          </span>
        )}
      </div>

      {/* Expanded Time Options */}
      {enabled && (
        <div
          className={`p-2.5 sm:p-3 rounded-2xl border ${currentTheme.border} ${currentTheme.bg} space-y-2.5 animate-in fade-in duration-150`}
        >
          {/* Mode Selector: تلقائي vs يدوي */}
          <div className="flex items-center gap-1.5 p-1 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-bold">
            <button
              type="button"
              onClick={() => onModeChange('auto')}
              className={`flex-1 py-1.5 px-2 rounded-lg transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                mode === 'auto' ? currentTheme.activeTab : currentTheme.inactiveTab
              }`}
            >
              <i className="fa-solid fa-wand-magic-sparkles text-[10px]"></i>
              <span>تلقائي</span>
            </button>
            <button
              type="button"
              onClick={() => {
                onModeChange('manual');
                if (!time) {
                  onTimeChange(getCurrentTimeStr());
                }
              }}
              className={`flex-1 py-1.5 px-2 rounded-lg transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                mode === 'manual' ? currentTheme.activeTab : currentTheme.inactiveTab
              }`}
            >
              <i className="fa-solid fa-clock text-[10px]"></i>
              <span>يدوي</span>
            </button>
          </div>

          {/* Mode Content */}
          {mode === 'auto' ? (
            <div className="flex items-center justify-between px-2.5 py-1.5 bg-white/80 dark:bg-slate-900/80 rounded-xl border border-slate-200/80 dark:border-slate-800 text-xs">
              <span className="text-slate-600 dark:text-slate-300 font-medium text-[11px] flex items-center gap-1.5">
                <i className={`fa-solid fa-circle-check text-[10px] ${currentTheme.icon}`}></i>
                <span>يأخذ وقت الجهاز الحالي تلقائياً:</span>
              </span>
              <span className="font-mono font-bold text-slate-800 dark:text-slate-100 text-[11px] bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-md">
                {currentTimeSample ? formatTimeOnly(new Date().toISOString()) : 'الآن'}
              </span>
            </div>
          ) : (
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-[11px]">
                <span className="font-bold text-slate-700 dark:text-slate-300">
                  تحديد الساعة والدقيقة:
                </span>
                <button
                  type="button"
                  onClick={() => onTimeChange(getCurrentTimeStr())}
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-md cursor-pointer transition-colors ${currentTheme.nowBtn}`}
                  title="ضبط على الوقت الحالي الآن"
                >
                  <i className="fa-solid fa-clock-rotate-left ml-1 text-[9px]"></i>
                  الآن
                </button>
              </div>

              <input
                type="time"
                value={time || getCurrentTimeStr()}
                onChange={(e) => onTimeChange(toEnglishDigits(e.target.value))}
                className={`w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-mono font-bold text-slate-900 dark:text-white outline-none focus:ring-2 transition-all text-center ${currentTheme.focusRing}`}
              />
            </div>
          )}
        </div>
      )}
    </div>
  );
};
