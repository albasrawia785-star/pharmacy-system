import React, { useState } from 'react';
import { SettledStorageStats, Debtor } from '../types';
import { formatNumber } from '../utils/formatters';
import { useI18n } from '../i18n/index.tsx';

interface SettledStorageWarningModalProps {
  isOpen: boolean;
  stats: SettledStorageStats | null;
  settledDebtorsList: Debtor[];
  onClose: () => void;
  onProceedAction: () => void;
  onGoToSettledList: () => void;
  onQuickBatchDelete: (debtorIds: number[]) => Promise<void>;
  actionTypeDescription?: string; // e.g. "إضافة دين" أو "تسديد دين"
}

export const SettledStorageWarningModal: React.FC<SettledStorageWarningModalProps> = ({
  isOpen,
  stats,
  settledDebtorsList,
  onClose,
  onProceedAction,
  onGoToSettledList,
  onQuickBatchDelete,
  actionTypeDescription = 'إضافة أو تسديد دين',
}) => {
  const { t, numberFormat } = useI18n();
  const [isCleaning, setIsCleaning] = useState(false);
  const [selectedIds, setSelectedIds] = useState<number[]>([]);
  const [viewMode, setViewMode] = useState<'overview' | 'quick_select'>('overview');
  const [dontShowAgainSession, setDontShowAgainSession] = useState(false);

  if (!isOpen) return null;

  const totalSettled = stats?.totalSettled ?? settledDebtorsList.length;
  const threshold = stats?.limitThreshold || 100;
  const dbCount = stats?.databasesCount || 3;

  // Initialize selected IDs with the first 5 or 10 oldest settled debtors if entering quick_select
  const handleOpenQuickSelect = () => {
    const defaultBatch = settledDebtorsList.slice(0, 10).map((d) => d.id);
    setSelectedIds(defaultBatch);
    setViewMode('quick_select');
  };

  const handleToggleSelect = (id: number) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleSelectAll = () => {
    if (selectedIds.length === settledDebtorsList.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(settledDebtorsList.map((d) => d.id));
    }
  };

  const handleConfirmBatchDelete = async () => {
    if (selectedIds.length === 0) return;
    try {
      setIsCleaning(true);
      await onQuickBatchDelete(selectedIds);
      if (dontShowAgainSession) {
        sessionStorage.setItem('aldion_settled_storage_alert_snoozed', 'true');
      }
      onClose();
    } finally {
      setIsCleaning(false);
    }
  };

  const handleProceed = () => {
    if (dontShowAgainSession) {
      sessionStorage.setItem('aldion_settled_storage_alert_snoozed', 'true');
    }
    onProceedAction();
    onClose();
  };

  const handleGoToList = () => {
    if (dontShowAgainSession) {
      sessionStorage.setItem('aldion_settled_storage_alert_snoozed', 'true');
    }
    onGoToSettledList();
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex justify-center items-center z-50 p-4 animate-in fade-in duration-150 select-none">
      <div
        className="bg-white rounded-3xl w-full max-w-md p-6 shadow-2xl relative border border-slate-200 text-start animate-in zoom-in-95 duration-200 max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Badge & Close Button */}
        <div className="flex items-center justify-between pb-3.5 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-slate-900 text-amber-400 flex items-center justify-center text-base border border-slate-800 shadow-sm">
              <i className="fa-solid fa-database"></i>
            </div>
            <div>
              <span className="text-[10px] font-bold text-slate-700 bg-slate-100 px-2.5 py-0.5 rounded-full inline-block border border-slate-200/80">
                إشعار نظام سعة قاعدة البيانات
              </span>
              <h3 className="font-bold text-sm text-slate-900 mt-0.5">
                تجاوز الحد المسموح به للمسددين ({formatNumber(totalSettled, numberFormat)} / {threshold})
              </h3>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center text-xs transition-colors cursor-pointer"
            title="إغلاق التنبيه"
          >
            <i className="fa-solid fa-xmark"></i>
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto py-4 space-y-4 text-xs text-slate-600">
          {viewMode === 'overview' ? (
            <>
              {/* Mandatory Official Notice text */}
              <div className="p-3.5 bg-slate-900 text-slate-100 border border-slate-800 rounded-2xl leading-relaxed shadow-sm">
                <div className="flex items-center gap-2 text-amber-400 font-bold text-xs mb-1.5 pb-1 border-b border-slate-800">
                  <i className="fa-solid fa-shield-halved"></i>
                  <span>تنبيه رسمي بشأن سعة التخزين:</span>
                </div>
                <p className="text-[11.5px] text-slate-300 leading-relaxed">
                  بلغ مجموع الحسابات الخالية من الدين والمكتمَلة بالكامل في كافة الأنظمة المربوطة <strong className="font-bold text-amber-300 font-mono text-xs">{formatNumber(totalSettled, numberFormat)}</strong> حساباً.
                </p>
                <div className="text-[11px] mt-2 text-rose-200 bg-rose-950/60 p-2.5 rounded-xl border border-rose-800/60 font-medium leading-relaxed">
                  يتوجب حذف عدد من الحسابات المسددة لتخفيض المجموع إلى أقل من {threshold} لتتمكن من إكمال عملية ({actionTypeDescription}).
                </div>
              </div>

              {/* Stats Grid */}
              <div className="grid grid-cols-2 gap-2.5">
                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200/80 flex flex-col justify-between">
                  <span className="text-[10.5px] text-slate-500 font-bold">مدينون مسددون</span>
                  <span className="text-base font-extrabold text-slate-900 font-mono mt-1">
                    {formatNumber(stats?.settledDebtors || settledDebtorsList.length, numberFormat)}
                  </span>
                </div>

                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200/80 flex flex-col justify-between">
                  <span className="text-[10.5px] text-slate-500 font-bold">أقساط مكتملة</span>
                  <span className="text-base font-extrabold text-slate-900 font-mono mt-1">
                    {formatNumber(stats?.settledInstallments || 0, numberFormat)}
                  </span>
                </div>

                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200/80 flex flex-col justify-between">
                  <span className="text-[10.5px] text-slate-500 font-bold">موردون مسددون</span>
                  <span className="text-base font-extrabold text-slate-900 font-mono mt-1">
                    {formatNumber(stats?.settledSuppliers || 0, numberFormat)}
                  </span>
                </div>

                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200/80 flex flex-col justify-between">
                  <span className="text-[10.5px] text-slate-500 font-bold">قواعد البيانات النشطة</span>
                  <span className="text-base font-extrabold text-blue-700 font-mono mt-1">
                    {formatNumber(dbCount, numberFormat)} قواعد
                  </span>
                </div>
              </div>

              {/* Database breakdown if present */}
              {stats?.breakdownByDb && stats.breakdownByDb.length > 0 && (
                <div className="border border-slate-200 rounded-2xl p-3 bg-slate-50/60">
                  <span className="text-[11px] font-bold text-slate-800 block mb-2">
                    توزيع المسددين عبر القواعد السحابية:
                  </span>
                  <div className="space-y-1.5">
                    {stats.breakdownByDb.map((db) => (
                      <div
                        key={db.dbId}
                        className="flex items-center justify-between text-[11px] bg-white p-2 px-3 rounded-xl border border-slate-200/60 shadow-2xs"
                      >
                        <span className="truncate max-w-[180px] text-slate-700 font-medium">
                          {db.dbName}
                        </span>
                        <span className="font-mono font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded text-[10px]">
                          {formatNumber(db.total, numberFormat)} مسدد
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          ) : (
            /* Quick Batch Select View */
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-800">
                  حدد الحسابات المسددة المطلوب حذفها ({selectedIds.length} محدد):
                </span>
                <button
                  type="button"
                  onClick={handleSelectAll}
                  className="text-[11px] text-blue-600 font-bold hover:underline cursor-pointer"
                >
                  {selectedIds.length === settledDebtorsList.length ? 'إلغاء تحديد الكل' : 'تحديد الكل'}
                </button>
              </div>

              <div className="max-h-56 overflow-y-auto space-y-1.5 border border-slate-200 rounded-2xl p-2 bg-slate-50">
                {settledDebtorsList.length === 0 ? (
                  <p className="text-center py-4 text-slate-400 text-xs">لا توجد حسابات مسددة متاحة محلياً للحذف السريع</p>
                ) : (
                  settledDebtorsList.slice(0, 40).map((d) => {
                    const isChecked = selectedIds.includes(d.id);
                    return (
                      <div
                        key={d.id}
                        onClick={() => handleToggleSelect(d.id)}
                        className={`flex items-center justify-between p-2 rounded-xl text-xs cursor-pointer transition-all border ${
                          isChecked
                            ? 'bg-rose-50/80 border-rose-200 text-rose-900 font-semibold'
                            : 'bg-white border-slate-100 text-slate-700 hover:bg-slate-50'
                        }`}
                      >
                        <div className="flex items-center gap-2 truncate">
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={() => {}}
                            className="rounded text-rose-600 focus:ring-rose-500 cursor-pointer pointer-events-none"
                          />
                          <span className="truncate">{d.name}</span>
                        </div>
                        <span className="text-[10px] bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full font-bold">
                          خالي من الدين
                        </span>
                      </div>
                    );
                  })
                )}
              </div>

              <button
                type="button"
                onClick={() => setViewMode('overview')}
                className="text-[11px] font-bold text-slate-500 hover:text-slate-800 flex items-center gap-1 cursor-pointer"
              >
                <i className="fa-solid fa-arrow-right"></i>
                <span>العودة للملخص</span>
              </button>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="pt-3 border-t border-slate-100 flex flex-col gap-2">
          {viewMode === 'overview' ? (
            <>
              {totalSettled < threshold ? (
                /* Allowed to proceed if total settled is now less than threshold */
                <button
                  type="button"
                  onClick={handleProceed}
                  className="w-full bg-emerald-600 hover:bg-emerald-700 active:scale-98 text-white py-3 rounded-xl font-bold text-xs shadow-md shadow-emerald-500/20 cursor-pointer transition-all flex items-center justify-center gap-2"
                >
                  <i className="fa-solid fa-circle-check"></i>
                  <span>تم توفير المساحة! متابعة {actionTypeDescription} الآن</span>
                </button>
              ) : (
                <>
                  {/* Primary: Return to Main Menu */}
                  <button
                    type="button"
                    onClick={handleGoToList}
                    className="w-full bg-slate-900 hover:bg-slate-800 active:scale-98 text-white py-3 rounded-xl font-bold text-xs shadow-md shadow-slate-900/20 cursor-pointer transition-all flex items-center justify-center gap-2"
                  >
                    <i className="fa-solid fa-house"></i>
                    <span>رجوع إلى القائمة الرئيسية</span>
                  </button>

                  {/* Secondary: Quick select and delete from inside modal */}
                  {settledDebtorsList.length > 0 && (
                    <button
                      type="button"
                      onClick={handleOpenQuickSelect}
                      className="w-full bg-rose-600 hover:bg-rose-700 active:scale-98 text-white py-3 rounded-xl font-bold text-xs shadow-md shadow-rose-500/20 cursor-pointer transition-all flex items-center justify-center gap-2"
                    >
                      <i className="fa-regular fa-trash-can"></i>
                      <span>تحديد وحذف سريع للمسددين لتفريغ المساحة</span>
                    </button>
                  )}
                </>
              )}
            </>
          ) : (
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleConfirmBatchDelete}
                disabled={isCleaning || selectedIds.length === 0}
                className="flex-1 bg-rose-600 hover:bg-rose-700 active:scale-98 text-white py-2.5 rounded-xl font-bold text-xs shadow-md shadow-rose-500/20 cursor-pointer transition-all flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {isCleaning ? (
                  <>
                    <i className="fa-solid fa-spinner fa-spin"></i>
                    <span>جاري الحذف وتوفير المساحة...</span>
                  </>
                ) : (
                  <>
                    <i className="fa-regular fa-trash-can"></i>
                    <span>تأكيد حذف {selectedIds.length} مسدد</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={() => setViewMode('overview')}
                disabled={isCleaning}
                className="bg-slate-100 hover:bg-slate-200 text-slate-700 py-2.5 px-4 rounded-xl font-bold text-xs cursor-pointer transition-all"
              >
                إلغاء
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
